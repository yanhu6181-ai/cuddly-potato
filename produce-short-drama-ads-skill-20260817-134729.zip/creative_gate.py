#!/usr/bin/env python3
"""Fail closed when a short-drama manifest does not contain real creative variety."""

from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any


REQUIRED_CREATIVE_FIELDS = (
    "opening_event",
    "first_frame",
    "first_30s_summary",
    "narrative_arc",
)


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def seconds(value: Any) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    parts = str(value).strip().split(":")
    if len(parts) != 3:
        raise ValueError(f"invalid timecode {value!r}")
    hours, minutes, secs = int(parts[0]), int(parts[1]), float(parts[2])
    if minutes not in range(60) or not 0 <= secs < 60:
        raise ValueError(f"invalid timecode {value!r}")
    return hours * 3600 + minutes * 60 + secs


def version_id(version: dict, position: int | None = None) -> str:
    return str(
        version.get("id")
        or version.get("version")
        or version.get("export_name")
        or f"row-{position or '?'}"
    )


def normalize_text(value: Any) -> str:
    return re.sub(r"[^\w]+", " ", str(value or "").casefold(), flags=re.UNICODE).strip()


def source_key(value: Any) -> str:
    return str(value or "").replace("\\", "/").casefold()


def merge(intervals: list[tuple[float, float]]) -> list[tuple[float, float]]:
    result: list[list[float]] = []
    for start, end in sorted(intervals):
        if not result or start > result[-1][1]:
            result.append([start, end])
        else:
            result[-1][1] = max(result[-1][1], end)
    return [(start, end) for start, end in result]


def first_window(version: dict, limit: float = 30.0) -> tuple[dict[str, list[tuple[float, float]]], float]:
    grouped: dict[str, list[tuple[float, float]]] = defaultdict(list)
    consumed = 0.0
    for segment in version.get("segments", []):
        start = seconds(segment["in"])
        end = seconds(segment["out"])
        available = max(0.0, end - start)
        take = min(limit - consumed, available)
        if take > 0:
            grouped[source_key(segment.get("source_file"))].append((start, start + take))
            consumed += take
        if consumed >= limit - 1e-6:
            break
    return {key: merge(items) for key, items in grouped.items()}, consumed


def shared_window_seconds(left: dict[str, list[tuple[float, float]]], right: dict[str, list[tuple[float, float]]]) -> float:
    shared = 0.0
    for source in left.keys() & right.keys():
        a_items, b_items = left[source], right[source]
        a_index = b_index = 0
        while a_index < len(a_items) and b_index < len(b_items):
            a_start, a_end = a_items[a_index]
            b_start, b_end = b_items[b_index]
            shared += max(0.0, min(a_end, b_end) - max(a_start, b_start))
            if a_end <= b_end:
                a_index += 1
            else:
                b_index += 1
    return shared


def first_frame_source(version: dict) -> tuple[str, float] | None:
    segments = version.get("segments") or []
    if not segments:
        return None
    first = segments[0]
    return source_key(first.get("source_file")), seconds(first.get("in"))


def controlled_pair(left: dict, right: dict) -> bool:
    group = str(left.get("controlled_group_id") or "").strip()
    return bool(
        group
        and group == str(right.get("controlled_group_id") or "").strip()
        and left.get("testing_mode") == "controlled_duration_test"
        and right.get("testing_mode") == "controlled_duration_test"
    )


def validate_winner_evidence(path: Path | None) -> list[str]:
    if path is None or not path.is_file():
        return [f"controlled iteration requires an existing winner evidence file: {path}"]
    try:
        payload = load(path)
    except (OSError, ValueError) as error:
        return [f"winner evidence is unreadable: {error}"]
    metrics = payload.get("metrics", {}) if isinstance(payload, dict) else {}
    failures = []
    for field in ("winner_id", "source"):
        if not str(payload.get(field, "")).strip():
            failures.append(f"winner evidence missing {field}")
    for field in ("paid_conversions", "spend", "cpa", "sample_size"):
        value = metrics.get(field, payload.get(field))
        try:
            if float(value) <= 0:
                raise ValueError
        except (TypeError, ValueError):
            failures.append(f"winner evidence {field} must be a positive number")
    return failures


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--required-unique-openings", type=int, default=0, help="0 requires one unique opening per version")
    parser.add_argument("--max-first-30-overlap", type=float, default=0.30)
    parser.add_argument("--same-first-frame-tolerance", type=float, default=1.0)
    parser.add_argument("--allow-controlled-iteration", action="store_true")
    parser.add_argument("--controlled-user-approved", action="store_true")
    parser.add_argument("--winner-evidence", type=Path)
    parser.add_argument("--enforce", action="store_true")
    args = parser.parse_args()

    payload = load(args.manifest)
    versions = payload.get("versions") if isinstance(payload, dict) else None
    if not isinstance(versions, list) or not versions:
        raise SystemExit("manifest.versions must be a non-empty list")
    required_unique = args.required_unique_openings or len(versions)
    failures: list[str] = []
    warnings: list[str] = []
    if required_unique < 1 or required_unique > len(versions):
        failures.append(f"required_unique_openings={required_unique} must be within 1..{len(versions)}")

    controlled = [row for row in versions if row.get("testing_mode") == "controlled_duration_test"]
    if controlled:
        if not args.allow_controlled_iteration:
            failures.append("controlled_duration_test is disabled; default to all_new_exploration")
        if not args.controlled_user_approved:
            failures.append("controlled_duration_test requires explicit user approval recorded in production config")
        failures.extend(validate_winner_evidence(args.winner_evidence))

    normalized_fields: dict[str, list[str]] = {field: [] for field in REQUIRED_CREATIVE_FIELDS}
    windows: list[tuple[dict[str, list[tuple[float, float]]], float]] = []
    first_frames: list[tuple[str, float] | None] = []
    for position, row in enumerate(versions, 1):
        label = version_id(row, position)
        for field in REQUIRED_CREATIVE_FIELDS:
            value = normalize_text(row.get(field))
            normalized_fields[field].append(value)
            if not value:
                failures.append(f"{label}: missing {field}")
        try:
            window, duration = first_window(row)
            windows.append((window, duration))
            first_frames.append(first_frame_source(row))
            if duration < 29.5:
                failures.append(f"{label}: manifest provides only {duration:.3f}s of opening material; at least 30s is required")
        except (KeyError, TypeError, ValueError) as error:
            windows.append(({}, 0.0))
            first_frames.append(None)
            failures.append(f"{label}: invalid opening source interval: {error}")

    unique_counts = {
        field: len({value for value in values if value})
        for field, values in normalized_fields.items()
    }
    for field, count in unique_counts.items():
        if count < required_unique:
            failures.append(f"{field}: only {count} unique values; require at least {required_unique}")

    pair_reports = []
    for left_index, left in enumerate(versions):
        for right_index in range(left_index + 1, len(versions)):
            right = versions[right_index]
            left_id = version_id(left, left_index + 1)
            right_id = version_id(right, right_index + 1)
            authorized_controlled = (
                controlled_pair(left, right)
                and args.allow_controlled_iteration
                and args.controlled_user_approved
            )
            left_window, left_duration = windows[left_index]
            right_window, right_duration = windows[right_index]
            shared = shared_window_seconds(left_window, right_window)
            shorter = min(left_duration, right_duration)
            ratio = shared / shorter if shorter else 0.0
            same_first_frame = False
            left_first, right_first = first_frames[left_index], first_frames[right_index]
            if left_first and right_first:
                same_first_frame = left_first[0] == right_first[0] and abs(left_first[1] - right_first[1]) <= args.same_first_frame_tolerance
            pair_reports.append({
                "left": left_id,
                "right": right_id,
                "controlled_pair": controlled_pair(left, right),
                "authorized_controlled_pair": authorized_controlled,
                "same_first_frame_source": same_first_frame,
                "shared_first_30_seconds": round(shared, 3),
                "first_30_overlap_of_shorter": round(ratio, 6),
            })
            if not authorized_controlled and same_first_frame:
                failures.append(f"{left_id}/{right_id}: same first-frame source within {args.same_first_frame_tolerance:.3f}s")
            if not authorized_controlled and ratio > args.max_first_30_overlap:
                failures.append(f"{left_id}/{right_id}: first-30 overlap {ratio:.6f}>{args.max_first_30_overlap:.6f}")
            if authorized_controlled and ratio >= 0.999:
                warnings.append(f"{left_id}/{right_id}: authorized controlled pair contains the full shorter opening")

    report = {
        "version_count": len(versions),
        "required_unique_openings": required_unique,
        "unique_counts": unique_counts,
        "controlled_version_count": len(controlled),
        "controlled_iteration_authorized": bool(
            controlled and args.allow_controlled_iteration and args.controlled_user_approved and not validate_winner_evidence(args.winner_evidence)
        ),
        "limits": {
            "max_first_30_overlap": args.max_first_30_overlap,
            "same_first_frame_tolerance": args.same_first_frame_tolerance,
        },
        "status": "pass" if not failures else "fail",
        "failures": failures,
        "warnings": warnings,
        "pairs": pair_reports,
    }
    output = args.output or args.manifest.with_name(f"{args.manifest.stem}-creative-gate.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(output)
    if args.enforce and failures:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
