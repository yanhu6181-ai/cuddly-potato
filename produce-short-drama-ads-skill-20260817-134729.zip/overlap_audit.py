#!/usr/bin/env python3
"""Audit pairwise source overlap in this skill's timestamp manifest."""

from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any


def seconds(value: Any) -> float:
    """Accept seconds or HH:MM:SS.mmm timecodes."""
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if ":" not in text:
        return float(text)
    parts = text.split(":")
    if len(parts) != 3:
        raise ValueError(f"Invalid timecode: {value!r}")
    hours, minutes, secs = parts
    return int(hours) * 3600 + int(minutes) * 60 + float(secs)


def episode_key(value: Any) -> str:
    """Normalize EP01, 1, and '01' to the same comparison key."""
    text = str(value).strip().casefold()
    match = re.fullmatch(r"(?:ep(?:isode)?[_ -]*)?0*(\d+)", text)
    return f"ep:{int(match.group(1))}" if match else f"raw:{text}"


def merged_intervals(version: dict) -> dict[str, list[tuple[float, float]]]:
    grouped: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for segment in version.get("segments", []):
        start = seconds(segment["in"])
        end = seconds(segment["out"])
        if end <= start:
            raise ValueError(f"Non-positive segment in {version_id(version)}: {segment}")
        grouped[episode_key(segment["episode"])].append((start, end))

    result: dict[str, list[tuple[float, float]]] = {}
    for episode, intervals in grouped.items():
        merged: list[list[float]] = []
        for start, end in sorted(intervals):
            if not merged or start > merged[-1][1]:
                merged.append([start, end])
            else:
                merged[-1][1] = max(merged[-1][1], end)
        result[episode] = [(start, end) for start, end in merged]
    return result


def version_id(version: dict) -> str:
    return str(version.get("id") or version.get("version") or version.get("export_name"))


def body_duration(version: dict) -> float:
    if version.get("body_duration") is not None:
        return float(version["body_duration"])
    return sum(seconds(item["out"]) - seconds(item["in"]) for item in version.get("segments", []))


def controlled_pair(left: dict, right: dict) -> bool:
    group = left.get("controlled_group_id")
    return bool(group and group == right.get("controlled_group_id") and left.get("testing_mode") == "controlled_duration_test" and right.get("testing_mode") == "controlled_duration_test")


def shared_seconds(left: dict, right: dict) -> float:
    left_intervals = merged_intervals(left)
    right_intervals = merged_intervals(right)
    shared = 0.0
    for episode in left_intervals.keys() & right_intervals.keys():
        a_items = left_intervals[episode]
        b_items = right_intervals[episode]
        a_index = b_index = 0
        while a_index < len(a_items) and b_index < len(b_items):
            a_start, a_end = a_items[a_index]
            b_start, b_end = b_items[b_index]
            shared += max(0.0, min(a_end, b_end) - max(a_start, b_start))
            if a_end <= b_end:
                a_index += 1
            else:
                b_index += 1
    return shared


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--first", type=int, default=0, help="Audit first N; 0 means all")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--max-average", type=float, default=0.05)
    parser.add_argument("--max-pair", type=float, default=0.30)
    parser.add_argument("--allow-controlled-overlap", action="store_true")
    parser.add_argument("--enforce", action="store_true")
    args = parser.parse_args()

    payload = json.loads(args.manifest.read_text(encoding="utf-8"))
    versions = payload["versions"] if isinstance(payload, dict) else payload
    if args.first > 0:
        versions = versions[: args.first]

    pairs = []
    for index, left in enumerate(versions):
        for right in versions[index + 1 :]:
            shared = shared_seconds(left, right)
            shorter = min(body_duration(left), body_duration(right))
            controlled = controlled_pair(left, right)
            pairs.append(
                {
                    "left": version_id(left),
                    "right": version_id(right),
                    "shared_seconds": round(shared, 3),
                    "overlap_of_shorter": round(shared / shorter if shorter else 0.0, 6),
                    "controlled_pair": controlled,
                    "threshold_exempt": bool(controlled and args.allow_controlled_overlap),
                }
            )

    overall_maximum = max(pairs, key=lambda item: item["overlap_of_shorter"], default=None)
    overall_average = sum(pair["overlap_of_shorter"] for pair in pairs) / len(pairs) if pairs else 0.0
    governed = [pair for pair in pairs if not pair["threshold_exempt"]]
    maximum = max(governed, key=lambda item: item["overlap_of_shorter"], default=None)
    average = sum(pair["overlap_of_shorter"] for pair in governed) / len(governed) if governed else 0.0
    failures = []
    if average > args.max_average:
        failures.append(f"average_overlap={average:.6f}>{args.max_average:.6f}")
    if maximum and maximum["overlap_of_shorter"] > args.max_pair:
        failures.append(f"maximum_pair={maximum['left']}/{maximum['right']}:{maximum['overlap_of_shorter']:.6f}>{args.max_pair:.6f}")
    report = {
        "version_count": len(versions),
        "pair_count": len(pairs),
        "zero_overlap_pairs": sum(pair["shared_seconds"] == 0 for pair in pairs),
        "governed_pair_count": len(governed),
        "controlled_pair_count": sum(pair["controlled_pair"] for pair in pairs),
        "exempt_pair_count": sum(pair["threshold_exempt"] for pair in pairs),
        "overall_average_overlap_of_shorter": round(overall_average, 6),
        "overall_maximum_overlap_pair": overall_maximum,
        "average_overlap_of_shorter": round(average, 6),
        "maximum_overlap_pair": maximum,
        "limits": {"max_average": args.max_average, "max_pair": args.max_pair},
        "status": "pass" if not failures else "fail",
        "failures": failures,
        "pairs": pairs,
    }
    output = args.output or args.manifest.with_name(
        f"{args.manifest.stem}-overlap-audit.json"
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(output)
    if args.enforce and failures:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
