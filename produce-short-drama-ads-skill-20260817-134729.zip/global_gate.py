#!/usr/bin/env python3
"""Cross-process FIFO mutexes and resource-slot gates."""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


def default_root() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA", Path.home()))
    return base / "Codex" / "produce-short-drama-ads" / "global-gate"


def alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        process_query_limited_information = 0x1000
        handle = ctypes.windll.kernel32.OpenProcess(
            process_query_limited_information, False, pid
        )
        if not handle:
            return False
        ctypes.windll.kernel32.CloseHandle(handle)
        return True
    try:
        os.kill(pid, 0)
        return True
    except PermissionError:
        return True
    except OSError:
        return False


def read(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def remove_stale(root: Path) -> None:
    locks = [root / "heavy.lock", *root.glob("slot-*.lock")]
    for path in list(root.glob("*.wait")) + locks:
        if path.exists() and not alive(int(read(path).get("pid", 0))):
            path.unlink(missing_ok=True)


@contextmanager
def heavy_gate(label: str, root: Path | None = None, timeout: float | None = None) -> Iterator[float]:
    root = (root or default_root()).resolve()
    root.mkdir(parents=True, exist_ok=True)
    pid = os.getpid()
    token = uuid.uuid4().hex
    ticket = root / f"{time.time_ns():020d}-{pid}-{token}.wait"
    ticket.write_text(json.dumps({"pid": pid, "label": label, "queued_epoch": time.time()}), encoding="utf-8")
    lock = root / "heavy.lock"
    started = time.monotonic()
    acquired = False
    try:
        while True:
            remove_stale(root)
            queue = sorted(root.glob("*.wait"), key=lambda path: path.name)
            if queue and queue[0] == ticket and not lock.exists():
                payload = json.dumps({"pid": pid, "token": token, "label": label, "acquired_epoch": time.time()})
                try:
                    descriptor = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                    with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                        handle.write(payload)
                    acquired = True
                    ticket.unlink(missing_ok=True)
                    break
                except FileExistsError:
                    pass
            if timeout is not None and time.monotonic() - started >= timeout:
                raise SystemExit(f"production gate is busy for {label}: {root}")
            time.sleep(1)
        yield time.monotonic() - started
    finally:
        ticket.unlink(missing_ok=True)
        if acquired and read(lock).get("token") == token:
            lock.unlink(missing_ok=True)


@contextmanager
def slot_gate(
    label: str,
    root: Path,
    slots: int,
    timeout: float | None = None,
) -> Iterator[tuple[float, int]]:
    """Acquire one fair cross-process slot from a bounded resource pool."""
    root = root.resolve()
    root.mkdir(parents=True, exist_ok=True)
    slots = max(1, slots)
    pid = os.getpid()
    token = uuid.uuid4().hex
    ticket = root / f"{time.time_ns():020d}-{pid}-{token}.wait"
    ticket.write_text(
        json.dumps({"pid": pid, "label": label, "queued_epoch": time.time()}),
        encoding="utf-8",
    )
    started = time.monotonic()
    acquired: Path | None = None
    try:
        while True:
            remove_stale(root)
            queue = sorted(root.glob("*.wait"), key=lambda path: path.name)
            if queue and queue[0] == ticket:
                for index in range(slots):
                    lock = root / f"slot-{index:03d}.lock"
                    payload = json.dumps({
                        "pid": pid,
                        "token": token,
                        "label": label,
                        "slot": index,
                        "acquired_epoch": time.time(),
                    })
                    try:
                        descriptor = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                            handle.write(payload)
                        acquired = lock
                        ticket.unlink(missing_ok=True)
                        break
                    except FileExistsError:
                        continue
            if acquired is not None:
                break
            if timeout is not None and time.monotonic() - started >= timeout:
                raise SystemExit(f"resource gate is busy for {label}: {root}")
            time.sleep(0.1)
        yield time.monotonic() - started, int(read(acquired).get("slot", -1))
    finally:
        ticket.unlink(missing_ok=True)
        if acquired is not None and read(acquired).get("token") == token:
            acquired.unlink(missing_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("status", "cleanup"))
    parser.add_argument("--root", type=Path, default=default_root())
    args = parser.parse_args()
    args.root.mkdir(parents=True, exist_ok=True)
    remove_stale(args.root)
    lock = read(args.root / "heavy.lock")
    slots = [read(path) for path in sorted(args.root.glob("slot-*.lock"))]
    queue = [read(path) for path in sorted(args.root.glob("*.wait"), key=lambda path: path.name)]
    print(json.dumps({"locked": bool(lock), "holder": lock or None, "slots": slots, "queued": queue}, ensure_ascii=False))


if __name__ == "__main__":
    main()
