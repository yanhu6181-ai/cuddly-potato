#!/usr/bin/env python3
"""Render one manifest version with fixed branding and tail rules."""

from __future__ import annotations

import argparse
import json
import subprocess
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def seconds(value: Any) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    parts = str(value).split(":")
    if len(parts) != 3:
        return float(value)
    return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])


def media(path: Path) -> dict:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries",
         "format=duration:stream=codec_type", "-of", "json", str(path)],
        check=True, capture_output=True, text=True,
    )
    return json.loads(result.stdout)


def filter_path(path: Path) -> str:
    return str(path.resolve()).replace("\\", "/").replace(":", r"\:").replace("'", r"\'")


def select_version(payload: Any, wanted: str) -> dict:
    rows = payload["versions"] if isinstance(payload, dict) else payload
    matches = [row for row in rows if str(row.get("id") or row.get("version") or row.get("export_name")) == wanted]
    if len(matches) != 1:
        raise SystemExit(f"expected one version {wanted!r}, found {len(matches)}")
    return matches[0]


def merged_config(payload: dict, mode: str) -> dict:
    result = {key: value for key, value in payload.items() if key != "modes"}
    result.update(payload.get("modes", {}).get(mode, {}))
    required = ("width", "height", "fps", "logo_file", "font_file", "title", "tail_file")
    missing = [key for key in required if not result.get(key)]
    if missing:
        raise SystemExit(f"render config missing: {', '.join(missing)}")
    return result


def asset(base: Path, value: str) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def validate_render(path: Path, expected_duration: float) -> None:
    info = media(path)
    streams = info.get("streams", [])
    stream_types = {str(row.get("codec_type")) for row in streams}
    actual_duration = float(info.get("format", {}).get("duration", 0))
    tolerance = max(0.35, expected_duration * 0.003)
    failures = []
    if "video" not in stream_types:
        failures.append("missing video stream")
    if "audio" not in stream_types:
        failures.append("missing audio stream")
    if actual_duration <= 0:
        failures.append("invalid duration")
    elif abs(actual_duration - expected_duration) > tolerance:
        failures.append(
            f"duration mismatch: expected={expected_duration:.3f}s actual={actual_duration:.3f}s"
        )
    if failures:
        raise RuntimeError("render validation failed: " + "; ".join(failures))


def publish_render(temporary: Path, destination: Path, retry_seconds: float = 8.0) -> None:
    deadline = time.monotonic() + retry_seconds
    while True:
        try:
            temporary.replace(destination)
            return
        except PermissionError as error:
            if time.monotonic() >= deadline:
                raise RuntimeError(
                    f"output is locked by another app; close the video and retry: {destination}"
                ) from error
            time.sleep(0.5)


def render(args: argparse.Namespace) -> None:
    payload = load(args.manifest)
    version = select_version(payload, args.id)
    config = merged_config(load(args.config), args.mode)
    width, height, fps = int(config["width"]), int(config["height"]), int(config["fps"])
    segments = version.get("segments", [])
    if not segments:
        raise SystemExit("version has no segments")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    # Keep drawtext's textfile outside user-controlled output paths. FFmpeg's
    # filter parser can mis-handle apostrophes in quoted Windows paths even
    # after escaping (for example, a drama title containing "Brother's").
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", suffix=".title.txt", prefix="codex-short-drama-", delete=False
    ) as title_handle:
        title_handle.write(str(config["title"]))
        title_file = Path(title_handle.name)
    logo = asset(args.config.parent, config["logo_file"])
    tail = asset(args.config.parent, config["tail_file"])
    font = asset(args.config.parent, config["font_file"])
    for asset_path in (logo, tail, font):
        if not asset_path.exists():
            raise SystemExit(f"missing asset: {asset_path}")

    command = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-stats", "-y"]
    for segment in segments:
        source = Path(segment["source_file"])
        if not source.exists():
            raise SystemExit(f"missing source: {source}")
        duration = float(segment.get("duration") or (seconds(segment["out"]) - seconds(segment["in"])))
        command += ["-ss", f"{seconds(segment['in']):.3f}", "-t", f"{duration:.3f}", "-i", str(source)]
    logo_index = len(segments)
    tail_index = logo_index + 1
    command += ["-loop", "1", "-i", str(logo), "-i", str(tail)]

    chains: list[str] = []
    concat_inputs: list[str] = []
    for index, segment in enumerate(segments):
        duration = float(segment.get("duration") or (seconds(segment["out"]) - seconds(segment["in"])))
        chains.append(
            f"[{index}:v]trim=duration={duration:.3f},setpts=PTS-STARTPTS,"
            f"scale={width}:{height}:force_original_aspect_ratio=decrease:flags=lanczos,"
            f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:black,fps={fps},setsar=1,format=yuv420p[v{index}]"
        )
        chains.append(
            f"[{index}:a]atrim=duration={duration:.3f},asetpts=PTS-STARTPTS,"
            "aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo"
            f"[a{index}]"
        )
        concat_inputs.append(f"[v{index}][a{index}]")
    chains.append("".join(concat_inputs) + f"concat=n={len(segments)}:v=1:a=1[rawv][rawa]")

    font_size = int(config.get("font_size", round(width * 0.045)))
    border_width = int(config.get("border_width", max(2, round(width * 0.003))))
    title_x = str(config.get("title_x", "(w-text_w)/2"))
    title_y = str(config.get("title_y", round(height * 0.08)))
    color = str(config.get("title_color", "#FFBF17"))
    border = str(config.get("border_color", "#24160F"))
    glow_width = int(config.get("glow_width", max(border_width + 2, round(width * 0.008))))
    glow_filter = (
        f"drawtext=fontfile='{filter_path(font)}':textfile='{filter_path(title_file)}':"
        f"fontcolor='{color}@0.30':fontsize={font_size}:borderw={glow_width}:bordercolor='{color}@0.30':"
        f"x={title_x}:y={title_y}"
    )
    text_filter = (
        f"drawtext=fontfile='{filter_path(font)}':textfile='{filter_path(title_file)}':"
        f"fontcolor='{color}':fontsize={font_size}:borderw={border_width}:bordercolor='{border}':"
        f"shadowcolor=black@0.45:shadowx=2:shadowy=3:x={title_x}:y={title_y}"
    )
    chains.append(f"[rawv]{glow_filter}[glow]")
    chains.append(f"[glow]{text_filter}[titled]")
    logo_width = int(config.get("logo_width", round(width * 0.18)))
    logo_x = str(config.get("logo_x", round(width * 0.04)))
    logo_y = str(config.get("logo_y", round(height * 0.07)))
    chains.append(f"[{logo_index}:v]scale={logo_width}:-1:flags=lanczos,format=rgba[logo]")
    chains.append(f"[titled][logo]overlay=x={logo_x}:y={logo_y}:eof_action=repeat:shortest=1[bodyv]")

    tail_info = media(tail)
    tail_duration = float(config.get("tail_duration") or tail_info["format"]["duration"])
    chains.append(
        f"[{tail_index}:v]trim=duration={tail_duration:.3f},setpts=PTS-STARTPTS,"
        f"scale={width}:{height}:force_original_aspect_ratio=decrease:flags=lanczos,"
        f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:black,fps={fps},setsar=1,format=yuv420p[tailv]"
    )
    chains.append("[bodyv][tailv]concat=n=2:v=1:a=0[outv]")
    if any(stream.get("codec_type") == "audio" for stream in tail_info.get("streams", [])):
        chains.append(
            f"[{tail_index}:a]atrim=duration={tail_duration:.3f},asetpts=PTS-STARTPTS,"
            "aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo[taila]"
        )
        chains.append("[rawa][taila]concat=n=2:v=0:a=1[joined_a]")
    else:
        chains.append(f"[rawa]apad=pad_dur={tail_duration:.3f}[joined_a]")
    # Apply a deterministic final true-peak limiter after all body and tail audio
    # have been joined. This prevents source peaks and hard-splice overs from
    # exceeding the delivery ceiling without changing the edit or duration.
    limiter_limit = float(config.get("audio_limiter_limit", 0.5))
    chains.append(
        f"[joined_a]alimiter=limit={limiter_limit:.6f}:attack=5:release=50:level=0[outa]"
    )

    encoder = str(config.get("video_encoder", "h264_nvenc"))
    command += ["-filter_complex", ";".join(chains), "-map", "[outv]", "-map", "[outa]",
                "-c:v", encoder]
    if "nvenc" in encoder:
        command += ["-preset", str(config.get("preset", "p5")), "-rc", "vbr", "-cq", str(config.get("cq", 20)), "-b:v", "0"]
    elif "qsv" in encoder:
        command += ["-preset", str(config.get("preset", "medium")), "-global_quality", str(config.get("cq", 20))]
    elif "amf" in encoder:
        quality = str(config.get("preset", "quality"))
        quantizer = str(config.get("cq", 20))
        command += ["-quality", quality, "-rc", "cqp", "-qp_i", quantizer, "-qp_p", quantizer]
    else:
        command += ["-preset", str(config.get("preset", "veryfast")), "-crf", str(config.get("cq", 20))]
    if config.get("maxrate"):
        command += ["-maxrate", str(config["maxrate"]), "-bufsize", str(config.get("bufsize", config["maxrate"]))]
    total = sum(float(item.get("duration") or (seconds(item["out"]) - seconds(item["in"]))) for item in segments) + tail_duration
    temporary_output = args.output.with_name(
        f".{args.output.stem}.rendering-{uuid.uuid4().hex}.mp4"
    )
    command += ["-g", str(config.get("gop", fps * 2)), "-pix_fmt", "yuv420p", "-r", str(fps),
                "-c:a", "aac", "-b:a", str(config.get("audio_bitrate", "192k")), "-ar", "48000", "-ac", "2",
                "-movflags", "+faststart", "-t", f"{total:.3f}", str(temporary_output)]
    try:
        subprocess.run(command, check=True)
        validate_render(temporary_output, total)
        publish_render(temporary_output, args.output)
    finally:
        title_file.unlink(missing_ok=True)
        temporary_output.unlink(missing_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--id", required=True)
    parser.add_argument("--mode", choices=("preview", "final"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    render(parser.parse_args())


if __name__ == "__main__":
    main()
