#!/usr/bin/env python3
"""Select a working H.264 encoder with a short real encode test."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import time
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    parser.add_argument("--disk-path", type=Path, default=Path.cwd())
    args = parser.parse_args()
    candidates = [
        ("h264_nvenc", "p5", ["-preset", "p5", "-rc", "vbr", "-cq", "23", "-b:v", "0"]),
        ("h264_qsv", "medium", ["-preset", "medium", "-global_quality", "23"]),
        ("h264_amf", "quality", ["-quality", "quality", "-rc", "cqp", "-qp_i", "23", "-qp_p", "23"]),
        ("libx264", "veryfast", ["-preset", "veryfast", "-crf", "23"]),
    ]
    tests = []
    selected = None
    for encoder, preset, encode_args in candidates:
        started = time.monotonic()
        result = subprocess.run(
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i",
             "testsrc2=size=360x640:rate=30:duration=0.5", "-an", "-c:v", encoder,
             *encode_args, "-f", "null", "-"], capture_output=True, text=True, timeout=15,
        )
        row = {"encoder": encoder, "preset": preset, "status": "pass" if result.returncode == 0 else "fail", "seconds": round(time.monotonic() - started, 3), "error": result.stderr.strip()[-500:]}
        tests.append(row)
        if result.returncode == 0:
            selected = row
            break
    if selected is None:
        raise SystemExit("no working H.264 encoder")
    disk_path = args.disk_path.resolve()
    disk_path.mkdir(parents=True, exist_ok=True)
    disk = shutil.disk_usage(disk_path)
    report = {
        "created_epoch": time.time(),
        "selected_encoder": selected["encoder"],
        "selected_preset": selected["preset"],
        "recommended_render_jobs": 2 if selected["encoder"] != "libx264" else 1,
        "cpu_count": os.cpu_count(),
        "disk_path": str(disk_path),
        "disk_free_bytes": disk.free,
        "tests": tests,
    }
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
