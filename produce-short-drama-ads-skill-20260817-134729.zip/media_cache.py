#!/usr/bin/env python3
"""Build reusable inventory, sparse-frame, and whisper.cpp transcript caches."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import fnmatch
import json
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Any


VERSION = "2"


def load(path: Path, default: Any) -> Any:
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default


def save(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def norm(path: Path) -> str:
    return os.path.normcase(str(path.resolve()))


def quick_hash(path: Path) -> str:
    digest = hashlib.sha256()
    size = path.stat().st_size
    with path.open("rb") as handle:
        digest.update(handle.read(1024 * 1024))
        if size > 1024 * 1024:
            handle.seek(max(0, size - 1024 * 1024))
            digest.update(handle.read(1024 * 1024))
    return digest.hexdigest()


def probe(path: Path) -> dict:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries",
         "format=duration,size:stream=codec_type,codec_name,width,height,avg_frame_rate,sample_rate,channels",
         "-of", "json", str(path)], check=True, capture_output=True, text=True,
    )
    return json.loads(result.stdout)


def validate_media(path: Path, media: dict) -> None:
    streams = media.get("streams", [])
    stream_types = {str(row.get("codec_type")) for row in streams}
    try:
        duration = float(media.get("format", {}).get("duration", 0))
    except (TypeError, ValueError):
        duration = 0
    failures = []
    if duration <= 0:
        failures.append("invalid duration")
    if "video" not in stream_types:
        failures.append("missing video stream")
    if "audio" not in stream_types:
        failures.append("missing audio stream")
    if failures:
        raise RuntimeError(f"invalid source {path}: {'; '.join(failures)}")


def inventory(args: argparse.Namespace) -> None:
    files: list[Path] = []
    for root in args.source_dir:
        for pattern in args.glob:
            files.extend(path for path in root.glob(pattern) if path.is_file())
    files = sorted({path.resolve() for path in files}, key=lambda path: str(path).casefold())
    if not files:
        raise SystemExit("no source media found")
    index_path = args.cache_dir / "inventory.json"
    old_payload = load(index_path, {"items": {}})
    old = old_payload.get("items", {})
    rows = dict(old)
    hits = 0

    def inspect(path: Path) -> tuple[str, dict, bool]:
        key = norm(path)
        before = path.stat()
        cached = old.get(key)
        content = quick_hash(path)
        after_hash = path.stat()
        if (before.st_size, before.st_mtime_ns) != (after_hash.st_size, after_hash.st_mtime_ns):
            raise RuntimeError(f"source changed while being inspected; wait for the copy to finish: {path}")
        if old_payload.get("version") == VERSION and cached and cached.get("size") == after_hash.st_size and cached.get("mtime_ns") == after_hash.st_mtime_ns and cached.get("quick_hash") == content:
            validate_media(path, cached.get("media", {}))
            return key, cached, True
        try:
            media = probe(path)
        except subprocess.CalledProcessError as error:
            detail = (error.stderr or error.stdout or "ffprobe failed").strip().splitlines()
            raise RuntimeError(
                f"source media is unreadable: {path}: {detail[-1] if detail else 'ffprobe failed'}"
            ) from error
        after_probe = path.stat()
        if (after_hash.st_size, after_hash.st_mtime_ns) != (after_probe.st_size, after_probe.st_mtime_ns):
            raise RuntimeError(f"source changed while being inspected; wait for the copy to finish: {path}")
        validate_media(path, media)
        fingerprint = hashlib.sha256(json.dumps({"path": key, "size": after_probe.st_size, "mtime_ns": after_probe.st_mtime_ns, "quick_hash": content, "media": media}, sort_keys=True).encode()).hexdigest()
        return key, {"path": str(path), "size": after_probe.st_size, "mtime_ns": after_probe.st_mtime_ns, "quick_hash": content, "fingerprint": fingerprint, "media": media}, False

    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        for key, row, hit in pool.map(inspect, files):
            rows[key] = row
            hits += int(hit)
    active_keys = [norm(path) for path in files]
    save(index_path, {"version": VERSION, "active_keys": active_keys, "items": rows})
    print(json.dumps({"found": len(files), "cache_hits": hits, "inspected": len(files) - hits, "index": str(index_path.resolve())}, ensure_ascii=False))


def cache_key(row: dict, settings: dict) -> str:
    return hashlib.sha256(json.dumps({"source": row["fingerprint"], "settings": settings}, sort_keys=True).encode()).hexdigest()


def sparse_frames(args: argparse.Namespace) -> None:
    inventory_data = load(args.cache_dir / "inventory.json", {})
    items = inventory_data.get("items", {})
    active_keys = inventory_data.get("active_keys", list(items))
    sources = [items[key] for key in active_keys if key in items]
    if args.include:
        sources = [row for row in sources if any(fnmatch.fnmatch(Path(row["path"]).name, pattern) for pattern in args.include)]
    if not sources:
        raise SystemExit("run inventory first")
    index_path = args.cache_dir / "frames-index.json"
    prior = load(index_path, {"items": {}}).get("items", {})
    rows = dict(prior)
    settings = {"interval": args.interval, "max_frames": args.max_frames, "width": args.width, "version": VERSION}
    hits = 0

    def extract(row: dict) -> tuple[str, dict, bool]:
        key = norm(Path(row["path"]))
        digest = cache_key(row, settings)
        directory = args.cache_dir / "frames" / digest
        existing = sorted(directory.glob("*.jpg")) if directory.exists() else []
        cached = prior.get(key, {})
        if cached.get("cache_key") == digest and existing:
            return key, cached, True
        directory.mkdir(parents=True, exist_ok=True)
        output = directory / "%04d.jpg"
        subprocess.run(
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", row["path"],
             "-vf", f"fps=1/{args.interval},scale={args.width}:-1:flags=lanczos", "-frames:v", str(args.max_frames), "-q:v", "3", str(output)],
            check=True,
        )
        files = sorted(directory.glob("*.jpg"))
        return key, {"cache_key": digest, "source_fingerprint": row["fingerprint"], "directory": str(directory.resolve()), "frames": [str(path.resolve()) for path in files], "settings": settings}, False

    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        for key, row, hit in pool.map(extract, sources):
            rows[key] = row
            hits += int(hit)
    save(index_path, {"version": VERSION, "items": rows})
    print(json.dumps({"sources": len(sources), "cache_hits": hits, "generated": len(sources) - hits, "index": str(index_path.resolve())}, ensure_ascii=False))


def transcript(args: argparse.Namespace) -> None:
    inventory_data = load(args.cache_dir / "inventory.json", {})
    items = inventory_data.get("items", {})
    active_keys = inventory_data.get("active_keys", list(items))
    sources = [items[key] for key in active_keys if key in items]
    if args.include:
        sources = [row for row in sources if any(fnmatch.fnmatch(Path(row["path"]).name, pattern) for pattern in args.include)]
    if not sources:
        raise SystemExit("run inventory first")
    for required in (args.whisper_cli, args.model):
        if not required.exists():
            raise SystemExit(f"missing transcription dependency: {required}")
    index_path = args.cache_dir / "transcript-index.json"
    prior = load(index_path, {"items": {}}).get("items", {})
    rows = dict(prior)
    settings = {"model": quick_hash(args.model), "language": args.language, "threads": args.threads, "version": VERSION}
    hits = 0

    def transcribe_one(row: dict) -> tuple[str, dict, bool]:
        key = norm(Path(row["path"]))
        digest = cache_key(row, settings)
        destination = args.cache_dir / "transcripts" / f"{digest}.json"
        cached = prior.get(key, {})
        if cached.get("cache_key") == digest and destination.exists() and destination.stat().st_size > 50:
            return key, cached, True
        destination.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="short_drama_asr_") as temp_text:
            temp = Path(temp_text)
            wav = temp / "audio.wav"
            prefix = temp / "result"
            subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", row["path"], "-map", "0:a:0", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(wav)], check=True)
            subprocess.run([str(args.whisper_cli), "-m", str(args.model), "-f", str(wav), "-l", args.language, "-t", str(args.threads), "-ojf", "-of", str(prefix), "-np"], check=True, cwd=str(args.whisper_cli.parent), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            raw = load(prefix.with_suffix(".json"), {})
        segments = []
        for item in raw.get("transcription", []):
            offsets = item.get("offsets", {})
            segments.append({"start": round(float(offsets.get("from", 0)) / 1000, 3), "end": round(float(offsets.get("to", 0)) / 1000, 3), "text": str(item.get("text", "")).strip()})
        save(destination, {"source_file": row["path"], "source_fingerprint": row["fingerprint"], "language": args.language, "segments": segments})
        return key, {"cache_key": digest, "source_fingerprint": row["fingerprint"], "transcript": str(destination.resolve()), "segment_count": len(segments), "settings": settings}, False

    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        for key, row, hit in pool.map(transcribe_one, sources):
            rows[key] = row
            hits += int(hit)
    save(index_path, {"version": VERSION, "items": rows})
    print(json.dumps({"sources": len(sources), "cache_hits": hits, "transcribed": len(sources) - hits, "index": str(index_path.resolve())}, ensure_ascii=False))


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    inv = sub.add_parser("inventory")
    inv.add_argument("--source-dir", type=Path, action="append", required=True)
    inv.add_argument("--glob", action="append", default=["*.mp4"])
    inv.add_argument("--cache-dir", type=Path, required=True)
    inv.add_argument("--jobs", type=int, default=3)
    inv.set_defaults(func=inventory)
    frames = sub.add_parser("frames")
    frames.add_argument("--cache-dir", type=Path, required=True)
    frames.add_argument("--interval", type=float, default=15)
    frames.add_argument("--max-frames", type=int, default=20)
    frames.add_argument("--width", type=int, default=270)
    frames.add_argument("--jobs", type=int, default=2)
    frames.add_argument("--include", action="append", default=[])
    frames.set_defaults(func=sparse_frames)
    asr = sub.add_parser("transcribe")
    asr.add_argument("--cache-dir", type=Path, required=True)
    asr.add_argument("--whisper-cli", type=Path, required=True)
    asr.add_argument("--model", type=Path, required=True)
    asr.add_argument("--language", default="en")
    asr.add_argument("--threads", type=int, default=6)
    asr.add_argument("--jobs", type=int, default=2)
    asr.add_argument("--include", action="append", default=[])
    asr.set_defaults(func=transcript)
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
