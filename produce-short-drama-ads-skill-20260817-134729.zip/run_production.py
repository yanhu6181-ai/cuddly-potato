#!/usr/bin/env python3
"""Single technical entry point for cached, incremental short-drama production."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import time
from datetime import timedelta
from pathlib import Path
from typing import Any
import uuid
from contextlib import nullcontext

from global_gate import default_root as default_gate_root
from global_gate import heavy_gate


ROOT = Path(__file__).resolve().parent
PIPELINE = ROOT / "production_pipeline.py"
MEDIA_CACHE = ROOT / "media_cache.py"
RENDERER = ROOT / "render_manifest.py"
QA = ROOT / "batch_qa.py"
OVERLAP = ROOT / "overlap_audit.py"
CREATIVE_GATE = ROOT / "creative_gate.py"
HARDWARE = ROOT / "hardware_probe.py"

CREATIVE_FIELDS = (
    "platform", "target_market", "testing_mode", "type", "hypothesis", "invariant",
    "changed_variable", "opening_hook", "opening_event", "first_frame", "first_30s_summary",
    "narrative_arc", "ab_group", "ab_variable", "ending_cliffhanger",
    "review_risk", "stage1_score", "stage1_status", "creative_score", "first_30s_score",
    "gate_status", "gate_failures", "conversion_question", "subtitle_language",
)


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def resolve(base: Path, value: str | None, default: str | None = None) -> Path | None:
    text = value if value is not None else default
    if text is None:
        return None
    path = Path(text)
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def seconds(value: str) -> float:
    parts = str(value).split(":")
    if len(parts) != 3:
        raise ValueError(f"invalid timecode {value!r}; expected HH:MM:SS.mmm")
    hours, minutes, secs = int(parts[0]), int(parts[1]), float(parts[2])
    if minutes not in range(60) or not 0 <= secs < 60:
        raise ValueError(f"invalid timecode {value!r}")
    return timedelta(hours=hours, minutes=minutes, seconds=secs).total_seconds()


def probed_duration(path: Path) -> float:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)],
        check=True, capture_output=True, text=True, timeout=15,
    )
    return float(result.stdout.strip())


def validate_manifest(path: Path, render_config: Path, strict_creative_gate: bool = True) -> None:
    payload = load(path)
    versions = payload.get("versions")
    if not isinstance(versions, list) or not versions:
        raise RuntimeError("manifest.versions must be a non-empty list")
    render = load(render_config)
    tail = resolve(render_config.parent, render.get("tail_file"))
    if tail is None or not tail.is_file():
        raise RuntimeError(f"render config tail_file is missing: {tail}")
    tail_duration = float(render.get("tail_duration") or probed_duration(tail))
    seen_ids: set[str] = set()
    seen_exports: set[str] = set()
    failures: list[str] = []
    for position, row in enumerate(versions, 1):
        version_id = str(row.get("id") or row.get("version") or "").strip()
        label = version_id or f"row {position}"
        if not version_id:
            failures.append(f"row {position}: missing id/version")
        elif version_id in seen_ids:
            failures.append(f"{label}: duplicate id/version")
        seen_ids.add(version_id)
        export_name = str(row.get("export_name", ""))
        if not export_name or Path(export_name).name != export_name or Path(export_name).suffix.lower() != ".mp4":
            failures.append(f"{label}: export_name must be a plain .mp4 filename")
        elif export_name in seen_exports:
            failures.append(f"{label}: duplicate export_name")
        seen_exports.add(export_name)
        segments = row.get("segments")
        if not isinstance(segments, list) or not segments:
            failures.append(f"{label}: segments must be a non-empty list")
            continue
        body_duration = 0.0
        for index, segment in enumerate(segments, 1):
            source = Path(str(segment.get("source_file", "")))
            try:
                start = seconds(segment["in"])
                end = seconds(segment["out"])
                duration = float(segment["duration"])
            except (KeyError, TypeError, ValueError) as error:
                failures.append(f"{label} segment {index}: {error}")
                continue
            if not source.is_absolute():
                failures.append(f"{label} segment {index}: source_file must be absolute")
            if not source.is_file():
                failures.append(f"{label} segment {index}: missing source_file {source}")
            if end <= start or duration <= 0 or abs((end - start) - duration) > 0.12:
                failures.append(f"{label} segment {index}: in/out/duration mismatch")
            body_duration += duration
        try:
            declared_body = float(row["body_duration"])
            declared_total = float(row["total_duration"])
            if abs(declared_body - body_duration) > 0.12:
                failures.append(f"{label}: body_duration does not equal segment sum")
            if abs(declared_total - (declared_body + tail_duration)) > 0.20:
                failures.append(f"{label}: total_duration does not equal body plus configured tail")
        except (KeyError, TypeError, ValueError):
            failures.append(f"{label}: body_duration and total_duration must be numeric")
        if strict_creative_gate:
            missing = [field for field in CREATIVE_FIELDS if field not in row]
            if missing:
                failures.append(f"{label}: missing creative fields {missing}")
            if row.get("stage1_status") != "pass" or row.get("gate_status") != "pass":
                failures.append(f"{label}: stage1_status and gate_status must both be pass")
            try:
                if float(row.get("creative_score", -1)) < 82 or float(row.get("first_30s_score", -1)) < 40:
                    failures.append(f"{label}: creative score gate is below 82 total or 40/50 first-three")
            except (TypeError, ValueError):
                failures.append(f"{label}: creative scores must be numeric")
            if row.get("gate_failures"):
                failures.append(f"{label}: gate_failures must be empty")
    if failures:
        raise RuntimeError("manifest validation failed:\n- " + "\n- ".join(failures))


def preview_fingerprint(config: dict, manifest: Path, render_config: Path) -> str:
    versions = []
    for original in load(manifest)["versions"]:
        row = dict(original)
        row.pop("dependency_hash", None)
        versions.append(row)
    render = load(render_config)
    assets = {}
    for key in ("logo_file", "font_file", "tail_file"):
        path = resolve(render_config.parent, render.get(key))
        if path is None or not path.is_file():
            raise RuntimeError(f"missing approval dependency {key}: {path}")
        assets[key] = {"path": str(path), "sha256": file_hash(path)}
    policy = {
        "strict_creative_gate": bool(config.get("strict_creative_gate", True)),
        "creative_gate": config.get("creative_gate", {}),
        "max_average_overlap": config.get("max_average_overlap", 0.05),
        "max_pair_overlap": config.get("max_pair_overlap", 0.30),
    }
    tools = {
        "renderer": file_hash(RENDERER),
        "creative_gate": file_hash(CREATIVE_GATE),
        "overlap_audit": file_hash(OVERLAP),
    }
    payload = {"versions": versions, "render": render, "assets": assets, "tools": tools, "policy": policy}
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()


def record_preview(config: dict, task_root: Path, manifest: Path, render_config: Path) -> None:
    save(task_root / "preview-fingerprint.json", {
        "fingerprint": preview_fingerprint(config, manifest, render_config),
        "versions": [str(row.get("id") or row.get("version")) for row in load(manifest)["versions"]],
        "recorded_epoch": time.time(),
    })


def require_preview_review(config: dict, base: Path, task_root: Path, manifest: Path, render_config: Path) -> Path:
    review_path = resolve(base, config.get("preview_review_file")) or (task_root / "preview-review.json")
    if not review_path.is_file():
        raise RuntimeError(f"preview review evidence is missing: {review_path}")
    payload = load(review_path)
    current = preview_fingerprint(config, manifest, render_config)
    if payload.get("preview_fingerprint") != current:
        raise RuntimeError("preview review evidence is stale; review the current preview set")
    reviews = payload.get("reviews")
    if not isinstance(reviews, dict):
        raise RuntimeError("preview review evidence must contain a reviews object keyed by version id")
    expected = {str(row.get("id") or row.get("version")) for row in load(manifest)["versions"]}
    if set(reviews) != expected:
        missing = sorted(expected - set(reviews))
        extra = sorted(set(reviews) - expected)
        raise RuntimeError(f"preview review ids do not match manifest; missing={missing}, extra={extra}")
    for version_id, row in reviews.items():
        if not isinstance(row, dict) or row.get("status") != "pass":
            raise RuntimeError(f"{version_id}: preview review status must be pass")
        for field in ("opening_event_confirmed", "first_frame_confirmed", "first_30s_confirmed"):
            if row.get(field) is not True:
                raise RuntimeError(f"{version_id}: preview review must confirm {field}")
        if not str(row.get("notes", "")).strip():
            raise RuntimeError(f"{version_id}: preview review notes are required")
    return review_path


def approve_preview(config: dict, base: Path, task_root: Path, manifest: Path, render_config: Path) -> None:
    preview = load(task_root / "preview-fingerprint.json") if (task_root / "preview-fingerprint.json").exists() else {}
    current = preview_fingerprint(config, manifest, render_config)
    if preview.get("fingerprint") != current:
        raise RuntimeError("preview is missing or stale; render and manually review the current preview before approval")
    review_path = require_preview_review(config, base, task_root, manifest, render_config)
    save(task_root / "preview-approval.json", {
        "fingerprint": current,
        "review_file": str(review_path),
        "review_file_sha256": file_hash(review_path),
        "approved_epoch": time.time(),
    })


def require_preview_approval(config: dict, task_root: Path, manifest: Path, render_config: Path) -> None:
    if not config.get("preview_approved"):
        raise RuntimeError("set preview_approved=true only after completing required manual preview review")
    approval = load(task_root / "preview-approval.json") if (task_root / "preview-approval.json").exists() else {}
    if approval.get("fingerprint") != preview_fingerprint(config, manifest, render_config):
        raise RuntimeError("preview approval is missing or stale; run --phase preview, review it, then run --phase approve")
    review_path = Path(str(approval.get("review_file", "")))
    if not review_path.is_file() or approval.get("review_file_sha256") != file_hash(review_path):
        raise RuntimeError("preview review evidence is missing or changed after approval")


def execute(command: list[str], log: list[dict], name: str) -> None:
    started = time.monotonic()
    result = subprocess.run(
        command,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
    )
    stdout = (result.stdout or "").strip()
    stderr = (result.stderr or "").strip()
    if len(stdout) > 6000:
        stdout = "..." + stdout[-6000:]
    if len(stderr) > 6000:
        stderr = "..." + stderr[-6000:]
    record = {"stage": name, "status": "pass" if result.returncode == 0 else "fail", "seconds": round(time.monotonic() - started, 3), "stdout": stdout, "stderr": stderr}
    log.append(record)
    if result.returncode:
        details = " | ".join(value for value in (stdout, stderr) if value)
        raise RuntimeError(f"{name} failed ({result.returncode}): {details or 'no error output'}")


def render_command_file(task_root: Path, manifest: Path, render_config: Path) -> Path:
    path = task_root / "render-command.json"
    save(path, [sys.executable, str(RENDERER), "--manifest", "{manifest}", "--config", str(render_config), "--id", "{id}", "--mode", "{mode}", "--output", "{output}"])
    return path


def controlled_iteration_authorized(config: dict) -> bool:
    policy = config.get("creative_gate", {})
    return bool(policy.get("allow_controlled_iteration") and policy.get("controlled_user_approved"))


def creative_gate_command(config: dict, base: Path, manifest: Path, task_root: Path) -> list[str]:
    policy = config.get("creative_gate", {})
    command = [
        sys.executable, str(CREATIVE_GATE), str(manifest),
        "--output", str(task_root / "creative-gate.json"),
        "--max-first-30-overlap", str(policy.get("max_first_30_overlap", 0.30)),
        "--same-first-frame-tolerance", str(policy.get("same_first_frame_tolerance", 1.0)),
        "--enforce",
    ]
    required = policy.get("required_unique_openings")
    if required is not None:
        command += ["--required-unique-openings", str(required)]
    if policy.get("allow_controlled_iteration"):
        command.append("--allow-controlled-iteration")
    if policy.get("controlled_user_approved"):
        command.append("--controlled-user-approved")
    evidence = resolve(base, policy.get("winner_evidence_file"))
    if evidence is not None:
        command += ["--winner-evidence", str(evidence)]
    return command


def overlap_command(config: dict, manifest: Path, output: Path) -> list[str]:
    command = [
        sys.executable, str(OVERLAP), str(manifest),
        "--output", str(output),
        "--max-average", str(config.get("max_average_overlap", 0.05)),
        "--max-pair", str(config.get("max_pair_overlap", 0.30)),
        "--enforce",
    ]
    if controlled_iteration_authorized(config):
        command.append("--allow-controlled-overlap")
    return command


def resolve_hardware(config: dict, render_config: Path, task_root: Path, log: list[dict]) -> Path:
    payload = load(render_config)
    for key in ("logo_file", "font_file", "tail_file"):
        if payload.get(key):
            payload[key] = str(resolve(render_config.parent, payload[key]))
    modes = payload.setdefault("modes", {})
    needs_probe = payload.get("video_encoder") in (None, "auto") or config.get("render_jobs") is None
    needs_probe = needs_probe or any(row.get("video_encoder") == "auto" for row in modes.values())
    if not needs_probe:
        return render_config
    profile = task_root / "hardware-profile.json"
    ttl_seconds = max(0.0, float(config.get("hardware_probe_ttl_hours", 24))) * 3600
    detected = load(profile) if profile.is_file() else {}
    reusable = (
        profile.is_file()
        and time.time() - profile.stat().st_mtime <= ttl_seconds
        and detected.get("selected_encoder")
        and detected.get("selected_preset")
        and detected.get("recommended_render_jobs")
    )
    if reusable:
        log.append({"stage": "hardware_probe", "status": "reused", "seconds": 0, "profile": str(profile)})
    else:
        execute(
            [
                sys.executable,
                str(HARDWARE),
                "--output",
                str(profile),
                "--disk-path",
                str(task_root),
            ],
            log,
            "hardware_probe",
        )
        detected = load(profile)
    if payload.get("video_encoder") in (None, "auto"):
        payload["video_encoder"] = detected["selected_encoder"]
        payload["preset"] = detected["selected_preset"]
    for row in modes.values():
        if row.get("video_encoder") == "auto":
            row["video_encoder"] = detected["selected_encoder"]
            row["preset"] = detected["selected_preset"]
    config.setdefault("render_jobs", detected["recommended_render_jobs"])
    resolved = task_root / "resolved-render-config.json"
    save(resolved, payload)
    return resolved


def prepare_command(manifest: Path, cache: Path, mode: str, render_config: Path, config: dict) -> list[str]:
    render = load(render_config)
    tail = resolve(render_config.parent, render["tail_file"])
    logo = resolve(render_config.parent, render["logo_file"])
    font = resolve(render_config.parent, render["font_file"])
    command = [sys.executable, str(PIPELINE), "prepare", str(manifest), "--cache-dir", str(cache), "--mode", mode,
               "--brand-config-file", str(render_config), "--tail-file", str(tail), "--render-config-file", str(render_config),
               "--dependency-file", str(logo), "--dependency-file", str(font), "--dependency-file", str(RENDERER),
               "--jobs", str(config.get("probe_jobs", 3))]
    for value in config.get("dependency_files", []):
        command += ["--dependency-file", str(Path(value).resolve())]
    return command


def run_cache(config: dict, base: Path, cache: Path, log: list[dict]) -> None:
    source_dirs = [resolve(base, value) for value in config.get("source_dirs", [])]
    if not source_dirs:
        raise RuntimeError("config.source_dirs is required for cache phase")
    command = [sys.executable, str(MEDIA_CACHE), "inventory", "--cache-dir", str(cache), "--jobs", str(config.get("probe_jobs", 3))]
    for directory in source_dirs:
        command += ["--source-dir", str(directory)]
    for pattern in config.get("source_globs", []):
        command += ["--glob", pattern]
    execute(command, log, "inventory")
    frame = config.get("frames", {})
    if frame.get("enabled", False):
        includes = frame.get("include", [])
        if not includes and not frame.get("allow_all"):
            raise RuntimeError("frames.include is required unless allow_all=true; do not extract frames for the whole series accidentally")
        frame_command = [sys.executable, str(MEDIA_CACHE), "frames", "--cache-dir", str(cache), "--interval", str(frame.get("interval", 15)), "--max-frames", str(frame.get("max_frames", 20)), "--width", str(frame.get("width", 270)), "--jobs", str(frame.get("jobs", 2))]
        for pattern in includes:
            frame_command += ["--include", pattern]
        execute(frame_command, log, "frames")
    transcription = config.get("transcription", {})
    if transcription.get("enabled"):
        includes = transcription.get("include", [])
        if not includes and not transcription.get("allow_all"):
            raise RuntimeError("transcription.include is required unless allow_all=true; do not transcribe the whole series accidentally")
        whisper = resolve(base, transcription.get("whisper_cli"))
        model = resolve(base, transcription.get("model"))
        command = [sys.executable, str(MEDIA_CACHE), "transcribe", "--cache-dir", str(cache), "--whisper-cli", str(whisper), "--model", str(model), "--language", str(transcription.get("language", "en")), "--threads", str(transcription.get("threads", 6)), "--jobs", str(transcription.get("jobs", 2))]
        for pattern in includes:
            command += ["--include", pattern]
        execute(command, log, "transcribe")


def encoder_resource_key(render_config: Path, mode: str) -> str:
    payload = load(render_config)
    encoder = str(payload.get("modes", {}).get(mode, {}).get("video_encoder") or payload.get("video_encoder") or "cpu")
    return "".join(character if character.isalnum() or character in "-_" else "_" for character in encoder.casefold())


def run_render(mode: str, config: dict, manifest: Path, cache: Path, task_root: Path, render_config: Path, resource_root: Path, log: list[dict]) -> Path:
    output_key = "preview_dir" if mode == "preview" else "final_staging_dir"
    output = resolve(task_root, config.get(output_key), "previews" if mode == "preview" else "final-staging")
    execute(prepare_command(manifest, cache, mode, render_config, config), log, f"prepare_{mode}")
    command_file = render_command_file(task_root, manifest, render_config)
    state = task_root / "render-state.json"
    metrics = task_root / f"{mode}-metrics.json"
    jobs = (config.get("preview_render_jobs") or 1) if mode == "preview" else (config.get("render_jobs") or 2)
    command = [sys.executable, str(PIPELINE), "run", str(manifest), "--mode", mode, "--output-dir", str(output), "--state", str(state), "--metrics", str(metrics), "--jobs", str(jobs), "--command-file", str(command_file)]
    if config.get("resource_scheduler", True):
        command += [
            "--resource-gate-dir", str(resource_root / "render" / encoder_resource_key(render_config, mode)),
            "--resource-slots", str(max(1, int(config.get("render_resource_slots", 2)))),
        ]
        if config.get("wait_for_resource_gate", True):
            command.append("--wait-for-resource-gate")
    execute(command, log, f"render_{mode}")
    return output


def publish(staging: Path, destination: Path, manifest: Path) -> None:
    expected = [str(row["export_name"]) for row in load(manifest)["versions"]]
    missing = [name for name in expected if not (staging / name).is_file()]
    unexpected = [path.name for path in staging.glob("*.mp4") if path.name not in expected]
    if missing or unexpected:
        raise RuntimeError(f"staging is not an exact manifest set; missing={missing}, unexpected={unexpected}")
    if destination.exists():
        raise RuntimeError(f"refusing to merge with or overwrite an existing delivery directory: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.parent / f".{destination.name}.publishing-{uuid.uuid4().hex}"
    temporary.mkdir()
    try:
        for name in expected:
            shutil.copy2(staging / name, temporary / name)
        temporary.replace(destination)
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        raise


def summary(config: dict, task_root: Path, started_epoch: float, log: list[dict], status: str) -> None:
    cache_hits = rendered = reused = 0
    final_render_seconds = 0.0
    for row in log:
        try:
            data = json.loads(str(row.get("stdout", "")).splitlines()[-1])
        except (ValueError, IndexError):
            data = {}
        cache_hits += int(data.get("cache_hits", 0))
        rendered += len(data.get("rendered", []))
        reused += len(data.get("reused", []))
        if row.get("stage") == "render_final":
            final_render_seconds += float(row.get("seconds", 0))
    report = {
        "status": status,
        "elapsed_seconds": round(time.time() - started_epoch, 3),
        "time_limit_enabled": False,
        "cache_hits": cache_hits,
        "rendered_versions": rendered,
        "reused_versions": reused,
        "final_render_seconds": round(final_render_seconds, 3),
        "stages": log,
    }
    save(task_root / "production-summary.json", report)
    print(json.dumps({key: report[key] for key in ("status", "elapsed_seconds", "time_limit_enabled", "cache_hits", "rendered_versions", "reused_versions", "final_render_seconds")}, ensure_ascii=False))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("config", type=Path)
    parser.add_argument("--phase", choices=("cache", "preview", "approve", "final", "all"), required=True)
    args = parser.parse_args()
    config_path = args.config.resolve()
    config = load(config_path)
    base = config_path.parent
    storage_root = resolve(base, config.get("storage_root")) or base
    task_root = resolve(storage_root, config.get("task_root"))
    cache = resolve(storage_root, config.get("cache_dir"))
    manifest = resolve(storage_root, config.get("manifest"))
    render_config = resolve(base, config.get("render_config"))
    if task_root is None or cache is None:
        raise SystemExit("task_root and cache_dir are required")
    if args.phase != "cache":
        missing = []
        if manifest is None or not manifest.is_file():
            missing.append("manifest")
        if render_config is None or not render_config.is_file():
            missing.append("render_config")
        if missing:
            raise SystemExit(
                f"{', '.join(missing)} must point to existing files for phase {args.phase}; "
                "run --phase cache first if the edit manifest is not ready"
            )
    task_root.mkdir(parents=True, exist_ok=True)
    if args.phase in ("final", "all"):
        final_staging = resolve(task_root, config.get("final_staging_dir"), "final-staging")
        if final_staging is None or not final_staging.is_relative_to(task_root):
            raise SystemExit("final_staging_dir must stay inside task_root")
        if config.get("publish"):
            if config.get("delivery_confirmed_by_user") is not True:
                raise SystemExit(
                    "publishing requires delivery_confirmed_by_user=true after the user explicitly "
                    "specifies the delivery_dir for this task"
                )
            destination = resolve(base, config.get("delivery_dir") or config.get("final_dir"))
            if destination is None:
                raise SystemExit("delivery_dir is required when publish=true")
    started_epoch = time.time()
    log: list[dict] = []
    final_gate_root = resolve(base, config.get("global_gate_dir")) or default_gate_root()
    task_gate_root = task_root / ".task-gate"
    label = f"{task_root.name}:{args.phase}"
    wait_for_task_gate = bool(config.get("wait_for_task_gate", False))
    task_gate_context = heavy_gate(label, task_gate_root, timeout=None if wait_for_task_gate else 0)
    with task_gate_context as queue_seconds:
        log.append({
            "stage": "task_queue",
            "status": "pass",
            "seconds": round(queue_seconds, 3),
            "gate": str(task_gate_root),
        })
        try:
            if args.phase in ("preview", "approve", "final", "all"):
                validate_manifest(manifest, render_config, bool(config.get("strict_creative_gate", True)))
                log.append({"stage": "manifest_validation", "status": "pass", "seconds": 0})
                render_config = resolve_hardware(config, render_config, task_root, log)
                if args.phase in ("preview", "all"):
                    execute(creative_gate_command(config, base, manifest, task_root), log, "creative_gate")
                    execute(overlap_command(config, manifest, task_root / "overlap-audit.json"), log, "overlap_preflight")
            if args.phase in ("cache", "all"):
                wait_for_cache_gate = bool(config.get("wait_for_cache_gate", True))
                cache_gate_root = cache / ".cache-gate"
                cache_gate_context = heavy_gate(
                    f"{cache.name}:cache",
                    cache_gate_root,
                    timeout=None if wait_for_cache_gate else 0,
                )
                with cache_gate_context as cache_queue_seconds:
                    log.append({
                        "stage": "cache_queue",
                        "status": "pass",
                        "seconds": round(cache_queue_seconds, 3),
                        "gate": str(cache_gate_root),
                    })
                    run_cache(config, base, cache, log)
            if args.phase in ("preview", "all"):
                run_render("preview", config, manifest, cache, task_root, render_config, final_gate_root, log)
                record_preview(config, task_root, manifest, render_config)
            if args.phase == "approve":
                approve_preview(config, base, task_root, manifest, render_config)
                log.append({"stage": "preview_approval", "status": "pass", "seconds": 0})
            if args.phase in ("final", "all"):
                require_preview_approval(config, task_root, manifest, render_config)
                legacy_global_gate = not config.get("resource_scheduler", True)
                wait_for_final_gate = bool(config.get("wait_for_global_gate", True))
                final_gate_context = (
                    heavy_gate(
                        f"{task_root.name}:final",
                        final_gate_root,
                        timeout=None if wait_for_final_gate else 0,
                    )
                    if legacy_global_gate
                    else nullcontext(0.0)
                )
                with final_gate_context as final_queue_seconds:
                    if legacy_global_gate:
                        log.append({
                            "stage": "final_legacy_queue",
                            "status": "pass",
                            "seconds": round(final_queue_seconds, 3),
                            "gate": str(final_gate_root),
                        })
                    staging = run_render("final", config, manifest, cache, task_root, render_config, final_gate_root, log)
                    final_mode = load(render_config).get("modes", {}).get("final", {})
                    qa = task_root / "final-qa.json"
                    qa_command = [sys.executable, str(QA), str(staging), "--output", str(qa), "--manifest", str(manifest), "--jobs", str(config.get("qa_jobs", 2)), "--width", str(final_mode.get("width", load(render_config).get("width", 1080))), "--height", str(final_mode.get("height", load(render_config).get("height", 1920))), "--fps", f"{final_mode.get('fps', load(render_config).get('fps', 30))}/1", "--max-peak", str(config.get("max_true_peak", -1.0))]
                    if config.get("resource_scheduler", True):
                        qa_command += [
                            "--resource-gate-dir", str(final_gate_root / "qa"),
                            "--resource-slots", str(max(1, int(config.get("qa_resource_slots", 2)))),
                        ]
                        if config.get("wait_for_resource_gate", True):
                            qa_command.append("--wait-for-resource-gate")
                    execute(qa_command, log, "final_qa")
                    if config.get("publish"):
                        if config.get("delivery_confirmed_by_user") is not True:
                            raise RuntimeError("delivery_dir is not confirmed by the user for this task")
                        destination = resolve(base, config.get("delivery_dir") or config.get("final_dir"))
                        if destination is None:
                            raise RuntimeError("delivery_dir is required when publish=true")
                        if staging.resolve() == destination.resolve():
                            raise RuntimeError("final_staging_dir and delivery_dir must be different")
                        publish(staging, destination, manifest)
                        log.append({"stage": "publish", "status": "pass", "seconds": 0, "destination": str(destination)})
            summary(config, task_root, started_epoch, log, "pass")
        except SystemExit:
            summary(config, task_root, started_epoch, log, "fail")
            raise
        except Exception as error:
            log.append({"stage": "exception", "status": "fail", "error": str(error)})
            summary(config, task_root, started_epoch, log, "fail")
            raise


if __name__ == "__main__":
    main()
