#!/usr/bin/env python3
"""Cache, dependency, timing, and incremental execution utilities."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from global_gate import slot_gate


SCRIPT_VERSION = "2"


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return {} if default is None else default
    return json.loads(path.read_text(encoding="utf-8"))


def save(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def stable_hash(payload: Any) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def normalized(path: Path) -> str:
    return os.path.normcase(str(path.resolve()))


def probe(path: Path) -> dict[str, Any]:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries",
         "format=duration,size:stream=index,codec_type,codec_name,width,height,avg_frame_rate,sample_rate,channels",
         "-of", "json", str(path)], check=True, capture_output=True, text=True,
    )
    return json.loads(result.stdout)


def media_failures(data: dict[str, Any]) -> list[str]:
    failures = []
    streams = data.get("streams", [])
    stream_types = {str(row.get("codec_type")) for row in streams}
    try:
        duration = float(data.get("format", {}).get("duration", 0))
    except (TypeError, ValueError):
        duration = 0
    if duration <= 0:
        failures.append("invalid duration")
    if "video" not in stream_types:
        failures.append("missing video stream")
    if "audio" not in stream_types:
        failures.append("missing audio stream")
    return failures


def quick_content_hash(path: Path, block: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    size = path.stat().st_size
    with path.open("rb") as handle:
        digest.update(handle.read(block))
        if size > block:
            handle.seek(max(0, size - block))
            digest.update(handle.read(block))
    return digest.hexdigest()


def config_file_hash(path: Path | None, fallback: str) -> str:
    if path is None:
        return fallback
    resolved = path.resolve()
    digest = hashlib.sha256(resolved.read_bytes()).hexdigest()
    return stable_hash({"path": normalized(resolved), "sha256": digest})


def fingerprint(path_text: str) -> tuple[str, dict[str, Any]]:
    path = Path(path_text).resolve()
    before = path.stat()
    quick_hash = quick_content_hash(path)
    media = probe(path)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise RuntimeError(f"source changed while being inspected; wait for the copy to finish: {path}")
    failures = media_failures(media)
    if failures:
        raise RuntimeError(f"invalid source {path}: {'; '.join(failures)}")
    value = {
        "path": normalized(path),
        "size": after.st_size,
        "mtime_ns": after.st_mtime_ns,
        "quick_hash": quick_hash,
        "media": media,
    }
    value["fingerprint"] = stable_hash(value)
    return normalized(path), value


def versions(payload: Any) -> list[dict[str, Any]]:
    return payload["versions"] if isinstance(payload, dict) else payload


def version_id(row: dict[str, Any]) -> str:
    return str(row.get("id") or row.get("version") or row.get("export_name"))


def source_paths(payload: Any) -> list[str]:
    result: dict[str, str] = {}
    for row in versions(payload):
        for segment in row.get("segments", []):
            text = str(segment["source_file"])
            result.setdefault(os.path.normcase(os.path.abspath(text)), text)
    return list(result.values())


def prepare(args: argparse.Namespace) -> None:
    payload = load(args.manifest)
    paths = source_paths(payload)
    cache_index_path = args.cache_dir / "source-index.json"
    old_payload = load(cache_index_path, {"sources": {}})
    old = old_payload.get("sources", {})
    found: dict[str, dict[str, Any]] = {}
    hits = 0

    def inspect(text: str) -> tuple[str, dict[str, Any], bool]:
        path = Path(text).resolve()
        key = normalized(path)
        stat = path.stat()
        cached = old.get(key)
        if old_payload.get("script_version") == SCRIPT_VERSION and cached and cached.get("size") == stat.st_size and cached.get("mtime_ns") == stat.st_mtime_ns:
            if cached.get("quick_hash") == quick_content_hash(path):
                return key, cached, True
        fresh_key, fresh = fingerprint(text)
        return fresh_key, fresh, False

    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        for key, value, hit in pool.map(inspect, paths):
            found[key] = value
            hits += int(hit)

    merged_sources = dict(old)
    merged_sources.update(found)
    save(cache_index_path, {"script_version": SCRIPT_VERSION, "updated_at": now(), "sources": merged_sources})
    dependency_files = []
    for item in args.dependency_file:
        resolved = item.resolve()
        dependency_files.append({"path": normalized(resolved), "sha256": hashlib.sha256(resolved.read_bytes()).hexdigest()})
    global_config = {
        "brand": config_file_hash(args.brand_config_file, args.brand_hash),
        "tail": config_file_hash(args.tail_file, args.tail_hash),
        "render": config_file_hash(args.render_config_file, args.render_hash),
        "mode": args.mode,
        "script_version": SCRIPT_VERSION,
        "dependency_files": dependency_files,
    }
    enriched = payload if isinstance(payload, dict) else {"versions": payload}
    enriched.setdefault("production", {})
    enriched["production"].update({
        "source_index": str(cache_index_path.resolve()),
        "source_fingerprints": {key: value["fingerprint"] for key, value in found.items()},
        "global_config": global_config,
        "prepared_at": now(),
    })
    for row in versions(enriched):
        deps = []
        for segment in row.get("segments", []):
            key = normalized(Path(str(segment["source_file"])))
            deps.append({
                "source": found[key]["fingerprint"],
                "in": segment.get("in"), "out": segment.get("out"),
                "duration": segment.get("duration"), "purpose": segment.get("purpose"),
            })
        version_config = {key: value for key, value in row.items() if key not in {"dependency_hash", "segments"}}
        row["dependency_hash"] = stable_hash({"segments": deps, "version": version_config, "global": global_config})
    save(args.output_manifest or args.manifest, enriched)
    print(json.dumps({"sources": len(paths), "cache_hits": hits, "cache_misses": len(paths) - hits}, ensure_ascii=False))


def build_proxies(args: argparse.Namespace) -> None:
    payload = load(args.manifest)
    production = payload.get("production", {}) if isinstance(payload, dict) else {}
    source_index = load(Path(production.get("source_index", args.cache_dir / "source-index.json")), {"sources": {}}).get("sources", {})
    settings = {"width": args.width, "height": args.height, "fps": args.fps, "encoder": args.encoder, "preset": args.preset, "cq": args.cq, "script_version": SCRIPT_VERSION}
    proxy_dir = args.cache_dir / "proxies"
    proxy_dir.mkdir(parents=True, exist_ok=True)
    index_path = args.cache_dir / "proxy-index.json"
    prior = load(index_path, {"proxies": {}}).get("proxies", {})
    rows: dict[str, dict[str, Any]] = dict(prior)
    jobs: list[tuple[str, dict[str, Any], Path, str]] = []
    hits = 0
    for source in source_paths(payload):
        key = normalized(Path(source))
        info = source_index.get(key)
        if not info:
            raise SystemExit(f"source has no prepared fingerprint: {source}")
        cache_key = stable_hash({"source": info["fingerprint"], "settings": settings})
        destination = proxy_dir / f"{cache_key}.mp4"
        cached = prior.get(key, {})
        if cached.get("cache_key") == cache_key and valid_output(destination):
            rows[key] = cached
            hits += 1
        else:
            jobs.append((key, info, destination, cache_key))

    def encode(item: tuple[str, dict[str, Any], Path, str]) -> tuple[str, dict[str, Any]]:
        key, info, destination, cache_key = item
        command = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", info["path"],
                   "-map", "0:v:0", "-map", "0:a:0?", "-vf", f"scale={args.width}:{args.height}:flags=lanczos", "-r", str(args.fps),
                   "-c:v", args.encoder, "-preset", args.preset]
        if "nvenc" in args.encoder:
            command += ["-rc", "vbr", "-cq", str(args.cq), "-b:v", "0"]
        else:
            command += ["-crf", str(args.cq)]
        command += ["-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-ac", "2", "-movflags", "+faststart", str(destination)]
        subprocess.run(command, check=True)
        return key, {"cache_key": cache_key, "source_fingerprint": info["fingerprint"], "source": info["path"], "proxy": str(destination.resolve()), "settings": settings, "created_at": now()}

    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        for key, row in pool.map(encode, jobs):
            rows[key] = row
    save(index_path, {"updated_at": now(), "proxies": rows})
    print(json.dumps({"referenced_sources": len(rows), "cache_hits": hits, "encoded": len(jobs), "index": str(index_path.resolve())}, ensure_ascii=False))


def output_path(row: dict[str, Any], directory: Path) -> Path:
    return directory / str(row["export_name"])


def output_failures(path: Path, expected_duration: float | None = None) -> list[str]:
    if not path.exists() or path.stat().st_size < 1024:
        return ["output is missing or smaller than 1 KiB"]
    try:
        data = probe(path)
        duration = float(data.get("format", {}).get("duration", 0))
        failures = media_failures(data)
        if expected_duration is not None and abs(duration - expected_duration) > max(0.35, expected_duration * 0.003):
            failures.append(f"duration mismatch: expected={expected_duration:.3f}s actual={duration:.3f}s")
        return failures
    except subprocess.CalledProcessError as error:
        detail = (error.stderr or error.stdout or "ffprobe failed").strip().splitlines()
        return [detail[-1] if detail else "ffprobe failed"]
    except (ValueError, OSError) as error:
        return [str(error)]


def valid_output(path: Path, expected_duration: float | None = None) -> bool:
    return not output_failures(path, expected_duration)


def log_tail(value: str | None, limit: int = 1800) -> str:
    text = (value or "").strip()
    return text if len(text) <= limit else "..." + text[-limit:]


def plan_dirty(payload: Any, output: Path, state: dict[str, Any], mode: str) -> tuple[list[dict[str, Any]], list[str]]:
    dirty, reused = [], []
    records = state.setdefault("renders", {}).setdefault(mode, {})
    for row in versions(payload):
        key = version_id(row)
        destination = output_path(row, output)
        record = records.get(key, {})
        expected = row.get("total_duration")
        if expected is None and row.get("segments"):
            expected = sum(float(item.get("duration", 0)) for item in row["segments"])
        if record.get("dependency_hash") == row.get("dependency_hash") and valid_output(destination, None if expected is None else float(expected)):
            reused.append(key)
        else:
            dirty.append(row)
    return dirty, reused


def command_for(template: list[str], row: dict[str, Any], manifest: Path, output: Path, mode: str) -> list[str]:
    values = {"id": version_id(row), "output": str(output_path(row, output)), "manifest": str(manifest), "mode": mode}
    return [part.format(**values) for part in template]


def incremental_run(args: argparse.Namespace) -> None:
    payload = load(args.manifest)
    state = load(args.state, {})
    args.output_dir.mkdir(parents=True, exist_ok=True)
    dirty, reused = plan_dirty(payload, args.output_dir, state, args.mode)
    if args.plan_only:
        print(json.dumps({"dirty": [version_id(x) for x in dirty], "reused": reused}, ensure_ascii=False))
        return
    command_text = args.command_file.read_text(encoding="utf-8") if args.command_file else args.command_json
    if not command_text:
        raise SystemExit("--command-file or --command-json is required unless --plan-only is used")
    template = json.loads(command_text)
    if not isinstance(template, list) or not all(isinstance(x, str) for x in template):
        raise SystemExit("--command-json must be a JSON string array")
    started = time.monotonic()
    records = state.setdefault("renders", {}).setdefault(args.mode, {})
    completed: list[tuple[str, float]] = []
    failures: list[dict[str, str]] = []

    def execute(row: dict[str, Any]) -> tuple[str, float, str | None]:
        item_started = time.monotonic()
        cmd = command_for(template, row, args.manifest.resolve(), args.output_dir.resolve(), args.mode)
        destination = output_path(row, args.output_dir)
        destination.parent.mkdir(parents=True, exist_ok=True)
        before = None if not destination.exists() else (destination.stat().st_size, destination.stat().st_mtime_ns)
        gate = (
            slot_gate(
                f"{args.output_dir.parent.name}:{args.mode}:{version_id(row)}",
                args.resource_gate_dir,
                args.resource_slots,
                timeout=None if args.wait_for_resource_gate else 0,
            )
            if args.resource_gate_dir
            else None
        )
        if gate is None:
            result = subprocess.run(
                cmd, text=True, encoding="utf-8", errors="replace", capture_output=True,
            )
        else:
            with gate:
                result = subprocess.run(
                    cmd, text=True, encoding="utf-8", errors="replace", capture_output=True,
                )
        elapsed = time.monotonic() - item_started
        after = None if not destination.exists() else (destination.stat().st_size, destination.stat().st_mtime_ns)
        updated = after is not None and after != before
        expected = row.get("total_duration")
        if expected is None and row.get("segments"):
            expected = sum(float(item.get("duration", 0)) for item in row["segments"])
        expected_value = None if expected is None else float(expected)
        validation = output_failures(destination, expected_value) if result.returncode == 0 and updated else []
        if result.returncode:
            detail = log_tail(result.stderr or result.stdout)
            error = f"renderer exit={result.returncode}: {detail or 'no error output'}"
        elif not updated:
            error = "renderer exited successfully but did not publish a new output"
        elif validation:
            error = "output validation failed: " + "; ".join(validation)
        else:
            error = None
        return version_id(row), elapsed, error

    remaining = list(dirty)
    while remaining:
        batch = remaining[: max(1, args.jobs)]
        remaining = remaining[len(batch):]
        with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
            results = list(pool.map(execute, batch))
        by_id = {version_id(row): row for row in batch}
        for key, elapsed, error in results:
            if error:
                failures.append({"id": key, "error": error})
                continue
            completed.append((key, elapsed))
            records[key] = {"dependency_hash": by_id[key].get("dependency_hash"), "output": str(output_path(by_id[key], args.output_dir).resolve()), "seconds": round(elapsed, 3), "completed_at": now()}
        save(args.state, state)
    report = {"status": "pass" if not failures else "fail", "mode": args.mode, "elapsed_seconds": round(time.monotonic() - started, 3), "rendered": [x for x, _ in completed], "reused": reused, "failures": failures}
    save(args.metrics, report)
    print(json.dumps(report, ensure_ascii=False))
    if failures:
        raise SystemExit(2)


def stage(args: argparse.Namespace) -> None:
    payload = load(args.state, {})
    stages = payload.setdefault("stages", {})
    record = stages.setdefault(args.name, {})
    if args.action == "begin":
        record.update({"status": "running", "started_at": now(), "started_epoch": time.time(), "input_hash": args.input_hash})
    elif args.action == "end":
        started = float(record.get("started_epoch", time.time()))
        record.update({"status": args.status, "ended_at": now(), "elapsed_seconds": round(time.time() - started, 3), "outputs": args.output, "cache_hits": args.cache_hits, "failures": args.failures})
        record.pop("started_epoch", None)
    else:
        if "started_epoch" not in record:
            raise SystemExit(f"stage {args.name!r} has not started")
        elapsed = time.time() - float(record["started_epoch"])
        record["elapsed_seconds"] = round(elapsed, 3)
    save(args.state, payload)
    print(json.dumps(record, ensure_ascii=False))


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    prep = sub.add_parser("prepare")
    prep.add_argument("manifest", type=Path)
    prep.add_argument("--output-manifest", type=Path)
    prep.add_argument("--cache-dir", type=Path, required=True)
    prep.add_argument("--mode", default="final")
    prep.add_argument("--brand-hash", default="")
    prep.add_argument("--tail-hash", default="")
    prep.add_argument("--render-hash", default="")
    prep.add_argument("--brand-config-file", type=Path)
    prep.add_argument("--tail-file", type=Path)
    prep.add_argument("--render-config-file", type=Path)
    prep.add_argument("--dependency-file", type=Path, action="append", default=[])
    prep.add_argument("--jobs", type=int, default=3)
    prep.set_defaults(func=prepare)

    proxy = sub.add_parser("proxy")
    proxy.add_argument("manifest", type=Path)
    proxy.add_argument("--cache-dir", type=Path, required=True)
    proxy.add_argument("--width", type=int, default=1080)
    proxy.add_argument("--height", type=int, default=1920)
    proxy.add_argument("--fps", type=int, default=30)
    proxy.add_argument("--encoder", default="h264_nvenc")
    proxy.add_argument("--preset", default="p5")
    proxy.add_argument("--cq", type=int, default=18)
    proxy.add_argument("--jobs", type=int, default=2)
    proxy.set_defaults(func=build_proxies)

    run = sub.add_parser("run")
    run.add_argument("manifest", type=Path)
    run.add_argument("--mode", choices=("preview", "final"), required=True)
    run.add_argument("--output-dir", type=Path, required=True)
    run.add_argument("--state", type=Path, required=True)
    run.add_argument("--metrics", type=Path, required=True)
    run.add_argument("--command-json")
    run.add_argument("--command-file", type=Path)
    run.add_argument("--jobs", type=int, default=2)
    run.add_argument("--resource-gate-dir", type=Path)
    run.add_argument("--resource-slots", type=int, default=2)
    run.add_argument("--wait-for-resource-gate", action="store_true")
    run.add_argument("--plan-only", action="store_true")
    run.set_defaults(func=incremental_run)

    timer = sub.add_parser("stage")
    timer.add_argument("state", type=Path)
    timer.add_argument("action", choices=("begin", "check", "end"))
    timer.add_argument("name")
    timer.add_argument("--input-hash", default="")
    timer.add_argument("--status", choices=("pass", "fail", "stopped"), default="pass")
    timer.add_argument("--output", action="append", default=[])
    timer.add_argument("--cache-hits", type=int, default=0)
    timer.add_argument("--failures", type=int, default=0)
    timer.set_defaults(func=stage)
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
