#!/usr/bin/env python3
"""Run one probe, one batched video decode, and one audio scan per final MP4."""

from __future__ import annotations

import argparse
import concurrent.futures
import io
import json
import re
import subprocess
import tempfile
import time
from pathlib import Path

from PIL import Image, ImageStat
from global_gate import slot_gate


SCRIPT_VERSION = "2"


def probe(path: Path) -> dict:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries",
         "format=duration,size:stream=codec_type,codec_name,width,height,avg_frame_rate,sample_rate,channels,duration",
         "-of", "json", str(path)], check=True, capture_output=True, text=True,
    )
    return json.loads(result.stdout)


def frame_stats(path: Path, times: list[float]) -> list[dict]:
    if not times:
        return []
    with tempfile.TemporaryDirectory(prefix="short_drama_qa_") as temp:
        directory = Path(temp)
        count = len(times)
        split = "".join(f"[v{i}]" for i in range(count))
        chains = [f"[0:v]split={count}{split}"]
        for index, timestamp in enumerate(times):
            chains.append(f"[v{index}]trim=start={timestamp:.6f}:end={timestamp + 0.12:.6f},setpts=PTS-STARTPTS[o{index}]")
        command = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", str(path), "-filter_complex", ";".join(chains)]
        for index in range(count):
            command += ["-map", f"[o{index}]", "-frames:v", "1", str(directory / f"{index:03d}.png")]
        subprocess.run(command, check=True)
        rows = []
        for index, timestamp in enumerate(times):
            frame_path = directory / f"{index:03d}.png"
            if not frame_path.is_file() or frame_path.stat().st_size == 0:
                for backoff in (0.25, 0.5, 1.0, 2.0, 5.0):
                    fallback_time = max(0.0, timestamp - backoff)
                    subprocess.run(
                        ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
                         "-ss", f"{fallback_time:.6f}", "-i", str(path), "-frames:v", "1",
                         "-threads", "1", str(frame_path)],
                        check=False,
                    )
                    if frame_path.is_file() and frame_path.stat().st_size > 0:
                        break
            if not frame_path.is_file() or frame_path.stat().st_size == 0:
                raise RuntimeError(f"unable to extract QA frame: {path} at {timestamp:.3f}s")
            image = Image.open(frame_path).convert("RGB")
            small = image.resize((54, 96))
            stat = ImageStat.Stat(small)
            mean = sum(stat.mean) / 3
            dark = sum(max(pixel) < 12 for pixel in small.getdata()) / (54 * 96)
            rows.append({"time": round(timestamp, 3), "mean_luma_proxy": round(mean, 2), "dark_pixel_ratio": round(dark, 4)})
        return rows


def audio_stats(path: Path) -> dict:
    result = subprocess.run(
        ["ffmpeg", "-hide_banner", "-nostats", "-i", str(path), "-vn", "-af",
         "ebur128=peak=true,silencedetect=noise=-50dB:d=2", "-f", "null", "-"],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    text = result.stderr
    integrated = re.findall(r"I:\s*([-.0-9]+) LUFS", text)
    true_peak = re.findall(r"Peak:\s*([-.0-9]+) dBFS", text)
    silences = re.findall(r"silence_duration:\s*([0-9.]+)", text)
    return {"integrated_lufs": float(integrated[-1]) if integrated else None, "true_peak_dbtp": float(true_peak[-1]) if true_peak else None, "silence_periods_seconds": [float(x) for x in silences], "decoder_exit": result.returncode}


def inspect(path: Path, args: argparse.Namespace, config: dict | None = None) -> dict:
    started = time.monotonic()
    config = config or {}
    data = probe(path)
    streams = data.get("streams", [])
    video = next((x for x in streams if x.get("codec_type") == "video"), {})
    audio = next((x for x in streams if x.get("codec_type") == "audio"), {})
    duration = float(data.get("format", {}).get("duration", 0))
    configured_body = float(config.get("body_duration", args.body_duration))
    body = min(configured_body if configured_body > 0 else duration, duration)
    points = [0.05, body * 0.25, body * 0.5, body * 0.75, max(0.05, body - 0.1)]
    if duration > body + 0.05:
        points += [min(duration - 0.05, body + 0.1), max(0.05, duration - 0.05)]
    points += [value for value in args.sample if 0 <= value < duration]
    points += [value for value in config.get("samples", []) if 0 <= value < duration]
    points = sorted(set(round(min(value, max(0, duration - 0.05)), 3) for value in points))
    frames = frame_stats(path, points)
    audio_report = audio_stats(path)
    failures = []
    if args.width and video.get("width") != args.width: failures.append(f"width={video.get('width')}")
    if args.height and video.get("height") != args.height: failures.append(f"height={video.get('height')}")
    if args.video_codec and video.get("codec_name") != args.video_codec: failures.append(f"video_codec={video.get('codec_name')}")
    if args.fps and video.get("avg_frame_rate") != args.fps: failures.append(f"fps={video.get('avg_frame_rate')}")
    if args.audio_codec and audio.get("codec_name") != args.audio_codec: failures.append(f"audio_codec={audio.get('codec_name')}")
    if args.sample_rate and str(audio.get("sample_rate")) != str(args.sample_rate): failures.append(f"sample_rate={audio.get('sample_rate')}")
    if args.channels and audio.get("channels") != args.channels: failures.append(f"channels={audio.get('channels')}")
    if duration <= 0: failures.append("invalid_duration")
    expected_total = config.get("total_duration")
    if expected_total is not None and abs(duration - float(expected_total)) > max(0.25, float(expected_total) * 0.002): failures.append(f"duration={duration:.3f}")
    try:
        video_duration = float(video.get("duration"))
        audio_duration = float(audio.get("duration"))
        if abs(video_duration - audio_duration) > 0.12: failures.append(f"av_duration_delta={abs(video_duration-audio_duration):.3f}")
    except (TypeError, ValueError):
        failures.append("stream_duration_missing")
    if frames and (frames[0]["mean_luma_proxy"] < 8 or frames[0]["dark_pixel_ratio"] > 0.97): failures.append("black_first_frame")
    if audio_report["decoder_exit"] != 0: failures.append("audio_decode_failed")
    if audio_report["true_peak_dbtp"] is None: failures.append("audio_peak_missing")
    elif audio_report["true_peak_dbtp"] > args.max_peak: failures.append(f"true_peak_dbtp={audio_report['true_peak_dbtp']}")
    stat = path.stat()
    return {"file": str(path.resolve()), "size": stat.st_size, "mtime_ns": stat.st_mtime_ns, "duration": round(duration, 3), "video": video, "audio": audio, "frame_samples": frames, "audio_scan": audio_report, "elapsed_seconds": round(time.monotonic() - started, 3), "status": "pass" if not failures else "fail", "failures": failures}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--resource-gate-dir", type=Path)
    parser.add_argument("--resource-slots", type=int, default=2)
    parser.add_argument("--wait-for-resource-gate", action="store_true")
    parser.add_argument("--body-duration", type=float, default=0)
    parser.add_argument("--sample", type=float, action="append", default=[])
    parser.add_argument("--width", type=int, default=1080)
    parser.add_argument("--height", type=int, default=1920)
    parser.add_argument("--video-codec", default="h264")
    parser.add_argument("--fps", default="30/1")
    parser.add_argument("--audio-codec", default="aac")
    parser.add_argument("--sample-rate", type=int, default=48000)
    parser.add_argument("--channels", type=int, default=2)
    parser.add_argument("--max-peak", type=float, default=-1.0)
    args = parser.parse_args()
    paths = sorted(args.directory.glob("*.mp4"))
    per_version = {}
    expected_names: list[str] | None = None
    duplicate_names: list[str] = []
    if args.manifest:
        manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
        items = manifest["versions"] if isinstance(manifest, dict) else manifest
        expected_names = [str(row["export_name"]) for row in items]
        duplicate_names = sorted({name for name in expected_names if expected_names.count(name) > 1})
        for row in items:
            cumulative = 0.0
            joins = []
            for segment in row.get("segments", [])[:-1]:
                cumulative += float(segment.get("duration", 0))
                joins.append(cumulative)
            per_version[str(row["export_name"])] = {"body_duration": float(row.get("body_duration", args.body_duration)), "total_duration": row.get("total_duration"), "samples": joins}
    started = time.monotonic()
    global_qa_config = {
        "script_version": SCRIPT_VERSION, "body_duration": args.body_duration,
        "samples": sorted(args.sample), "width": args.width, "height": args.height,
        "video_codec": args.video_codec, "fps": args.fps, "audio_codec": args.audio_codec,
        "sample_rate": args.sample_rate, "channels": args.channels, "max_peak": args.max_peak,
    }
    previous = {}
    if args.output.exists():
        try:
            old_report = json.loads(args.output.read_text(encoding="utf-8"))
            previous = {row["file"]: row for row in old_report.get("files", [])}
        except (OSError, ValueError, KeyError):
            previous = {}
    reused, dirty = [], []
    for path in paths:
        key = str(path.resolve())
        stat = path.stat()
        row = previous.get(key)
        item_config = {"global": global_qa_config, "version": per_version.get(path.name, {})}
        if row and row.get("size") == stat.st_size and row.get("mtime_ns") == stat.st_mtime_ns and row.get("qa_config") == item_config:
            reused.append(row)
        else:
            dirty.append(path)
    def inspect_configured(path: Path) -> dict:
        config = per_version.get(path.name, {})
        gate = (
            slot_gate(
                f"qa:{path.name}",
                args.resource_gate_dir,
                args.resource_slots,
                timeout=None if args.wait_for_resource_gate else 0,
            )
            if args.resource_gate_dir
            else None
        )
        if gate is None:
            row = inspect(path, args, config)
        else:
            with gate:
                row = inspect(path, args, config)
        row["qa_config"] = {"global": global_qa_config, "version": config}
        return row

    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        fresh = list(pool.map(inspect_configured, dirty))
    rows_by_path = {row["file"]: row for row in reused + fresh}
    rows = [rows_by_path[str(path.resolve())] for path in paths]
    actual_names = [path.name for path in paths]
    missing = [] if expected_names is None else sorted(set(expected_names) - set(actual_names))
    extra = [] if expected_names is None else sorted(set(actual_names) - set(expected_names))
    report = {"qa_config": global_qa_config, "expected": None if expected_names is None else len(expected_names), "found": len(rows), "passed": sum(x["status"] == "pass" for x in rows), "missing": missing, "extra": extra, "duplicate_export_names": duplicate_names, "cache_hits": len(reused), "inspected": len(fresh), "elapsed_seconds": round(time.monotonic() - started, 3), "files": rows}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("found", "passed", "cache_hits", "inspected", "elapsed_seconds")}, ensure_ascii=False))
    if report["found"] != report["passed"] or missing or extra or duplicate_names:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
