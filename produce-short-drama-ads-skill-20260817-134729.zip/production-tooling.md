# 固定生产工具说明

批量短剧任务必须使用本页工具。任务专用脚本只负责工具尚不支持的非通用创意逻辑，不得重新实现缓存、全量循环、阶段计时、渲染或质检循环。

## 统一入口

先把当前目录切换到本 Skill 根目录（即包含 `SKILL.md` 与 `scripts/` 的目录）。从 [生产配置模板](../assets/production-config.example.json)、[渲染配置模板](../assets/render-config.example.json) 和 [清单模板](../assets/manifest.example.json) 复制任务文件，填写真实绝对路径。先缓存技术证据：

```powershell
python scripts/run_production.py <production-config.json> --phase cache
```

首次缓存配置只需提供 `task_root`、`cache_dir` 和 `source_dirs`；此时可以还没有 `manifest` 与 `render_config`。工具会拒绝仍在复制、缺少音视频轨或无法探测的源文件，并指出具体路径。

锁定并评分通过 `manifest.json` 后生成增量预览：

```powershell
python scripts/run_production.py <production-config.json> --phase preview
```

预览前统一入口会先执行 `creative_gate.py` 与重合率预检。默认要求版本数等于独立开场事件、独立首帧和独立前 30 秒数量；未通过时不会开始 FFmpeg。`controlled_duration_test` 只有生产配置显式批准、用户当前任务已授权且提供符合 [胜者证据模板](../assets/winner-evidence.example.json) 的数据文件时才可使用。

完成人工预览复审后，按 [预览复审模板](../assets/preview-review.example.json) 为每个版本记录开场事件、首帧和前 30 秒确认，并绑定当前 `preview-fingerprint.json`。再把 `preview_approved` 明确改为 `true`，生成正式片和执行技术质检：

```powershell
python scripts/run_production.py <production-config.json> --phase approve
python scripts/run_production.py <production-config.json> --phase final
```

`approve` 会校验逐条复审证据，并把人工批准绑定到当前清单、Logo、字体、尾帧、渲染配置和固定渲染器；任一依赖变化都会自动使复审与批准失效。`--phase all` 只适合已有同一指纹批准记录的断点续跑，不能代替人工预览。统一入口自动生成 `production-summary.json`，汇总整单耗时、缓存命中、实际渲染和复用版本数。任务不设固定时长上限，耗时本身不会触发自动停止。

`run_production.py` 自动用正式质量参数短测 NVENC、QSV、AMF 和 libx264；配置写 `video_encoder: auto` 时使用第一个实际通过的编码器，并根据编码器与 CPU 给出保守并发数。同一任务的有效硬件探测默认复用 24 小时，过期或结果缺失时重测。磁盘空间与源盘／网络吞吐仍需在真实任务开始前核对。固定渲染器直接读取清单，一次完成切段、拼接、Logo、英文剧名和 MOV 尾帧，不再生成任务专用 FFmpeg 渲染器。

不同剧、不同 `task_root` 可同时执行缓存、转写、抽帧、探测、预览、正式渲染和 QA；每个任务目录使用独立任务锁，防止两个对话同时修改同一任务。同一个 `cache_dir` 的写入另用缓存锁排队，避免同剧多个任务覆盖共享索引。预览默认每任务 1 路；预览和正式渲染的每条作业按实际编码器进入共享资源池，默认全机共 2 个编码槽，QA 使用独立的 2 槽资源池。资源池按等待顺序分配，因此长批次不能持续占住后续任务；发布不占编码槽，只校验并原子发布当前任务的独立目录。仅为兼容低资源旧流程，配置 `resource_scheduler=false` 时才恢复整单全局门。

正式渲染固定写入任务内部 `final_staging_dir`；`delivery_dir` 仅在整批 QA 通过后用于一次性目录发布。旧配置中的 `final_dir` 只作为交付目录兼容读取，绝不再作为正式渲染暂存目录。

转写和稀疏抽帧默认关闭；需要时必须分别在 `transcription.include`、`frames.include` 中明确本阶段剧集文件名模式，或明确设置 `allow_all: true`。不得因为启用证据生成而意外处理全集。缓存索引跨任务保留，源片内容、模型、语言或参数变化时只失效对应条目。

以下命令仅用于统一入口排错或单阶段诊断，常规任务不得手工拼接替代统一入口。

## 1. 准备指纹与版本依赖

正式预览前运行：

```powershell
python scripts/production_pipeline.py prepare <manifest.json> `
  --cache-dir <剧名工作区\_cache> `
  --mode preview `
  --brand-config-file <品牌配置.json> `
  --tail-file <尾帧.mov> `
  --render-config-file <预览参数.json> `
  --dependency-file <Logo文件> `
  --dependency-file <字体文件> `
  --dependency-file <任务渲染器.py>
```

该命令只探测清单实际引用的源文件，复用未变化源指纹，并把每条 `dependency_hash` 写回清单。正式片使用正式参数重新执行一次 `prepare --mode final`。优先传入真实配置／资产文件，让工具计算品牌、尾帧和渲染哈希；Logo、字体、任务渲染器及配置引用的其他外部资产必须逐个作为 `--dependency-file` 传入，不得使用随意常量掩盖变化。

仅在直接读取源片确实较慢或参数不兼容时运行 `proxy`。它只生成清单引用源的代理，不得用尚未锁定的全集清单触发全集转码：

```powershell
python scripts/production_pipeline.py proxy <manifest.json> --cache-dir <剧名工作区\_cache> --jobs 2
```

## 2. 阶段计时与断点续跑

每个阶段开始、执行中和结束分别运行：

```powershell
python scripts/production_pipeline.py stage <stage_state.json> begin <阶段名>
python scripts/production_pipeline.py stage <stage_state.json> check <阶段名>
python scripts/production_pipeline.py stage <stage_state.json> end <阶段名> --status pass --cache-hits <命中数>
```

阶段状态只记录实际耗时，不设置阶段或整单的固定时长上限。任务会持续运行到完成、用户主动停止、发生实际错误、资源不足或质量门禁失败；中断后继续运行时复用缓存和已成功版本，只处理 dirty 版本。

## 3. 只渲染 dirty 版本

统一入口自动生成指向固定 `render_manifest.py` 的内部命令文件。排错时可用 `--plan-only` 核对 dirty 与 reused：

```powershell
python scripts/production_pipeline.py run <manifest.json> `
  --mode preview --output-dir <previews> `
  --state <render_state.json> --metrics <preview_metrics.json> `
  --plan-only

```

固定渲染器单次调用只生产指定版本。工具验证输出包含音视频轨、可解码且总时长符合清单后才登记成功；中断后重跑会自动复用成功版本。修改单条切点只会让该条变 dirty；修改全局品牌、字体、尾帧、固定渲染器或正式参数会使所有依赖版本变 dirty。

每条输出先写入同目录临时 MP4，校验通过后才原子替换目标文件。渲染中断不会破坏已有成片；目标文件被播放器占用时会返回明确的文件占用提示，关闭播放器后重跑即可。单条失败报告必须包含版本号和底层 FFmpeg／校验原因，不得只返回 `exit=1`。

## 4. 合并自动质检

```powershell
python scripts/batch_qa.py <最终MP4目录> --output <final_qa.json> --manifest <manifest.json> --jobs 2
```

工具从清单读取每条独立正文时长和拼接点。它对每条 MP4 执行一次 `ffprobe`、一次批量画面解码和一次 EBU R128 真峰值／静音完整音频扫描；文件和全部质检参数未变化时才复用已有结果，默认真峰值不高于 -1 dBTP。它负责媒体参数、黑首帧、批量画面证据和音频技术检查，不替代人工连续观看、Logo／剧名视觉核验、平台审核和重合率审计。
