﻿# produce-short-drama-ads skill

Project-local Codex skill for short-drama ad production workflow.

This repository intentionally contains only the skill instructions, scripts, references, and example config. It does not include source media, caches, transcripts, rendered videos, or delivery outputs.
